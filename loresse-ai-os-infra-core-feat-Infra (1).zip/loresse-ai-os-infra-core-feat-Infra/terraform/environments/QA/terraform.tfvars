location = "centralus"
resource_group_names = {
  container_env       = "rg-cae-aios-qa-centralus"
  keyvault            = "rg-kv-aios-qa-centralus"
  openai              = "rg-openai-aios-qa-centralus"
  email_communication = "rg-ecs-aios-qa-centralus"
  communication       = "rg-comms-aios-qa-centralus"
  database            = "rg-psql-aios-qa-centralus"
  storage             = "rg-sa-aios-qa-centralus"
}

container_apps_config = {
  env_name = "cae-aios-lor-qa-centralus"
  apps = {
    login = "aca-aios-lor-qa-centralus-ls"
    ui    = "aca-aios-lor-qa-centralus-ui"
    api   = "aca-aios-lor-qa-centralus-api"
  }
}

managed_identity_config = {
  name = "uami-aios-lor-qa-centralus"
}

keyvault_config = {
  kv_name               = "kv-aios-lor-qa-cus"
  private_endpoint_name = "pep-kv-lor-qa-centralus"
}

openai_config = {
  name                  = "openai-aios-lor-qa-centralus"
  private_endpoint_name = "pep-openai-lor-qa-centralus"
}

ecs_config = {
  services = {
    email = "ecs-aios-lor-qa-centralus"
  }
}

communication_config = {
  services = {
    communication = "comms-aios-lor-qa-centralus"
  }
}

database_config = {
  db_name = "psql-aios-lor-qa-centralus"
}

storage_config = {
  storage_account_name   = "saaioslorqacentralus"
  blob_container_name    = "blobaioslorqacentralus"
  private_endpoint_name  = "pep-sa-aios-lor-qa-centralus"
  allowed_ip_ranges      = [] # Add GitHub Actions runner IP(s) here or your Terraform client IP
  allowed_subnets        = [] # Add additional subnet IDs if needed
}

vnet_config = {
  name                = "vnet-aios-lor-qa-centralus"
  resource_group_name = "rg-vnet-aios-qa-centralus"
}

subnet_configs = {
  container_apps = {
    address_prefixes = ["10.131.0.0/24"]
    subnet_name      = "snet-app-lor-qa-centralus"
  }
}

database_subnet_config = {
  address_prefixes = ["10.131.2.0/24"]
  subnet_name      = "snet-db-lor-qa-centralus"
}

private_endpoint_subnet_configs = {
  private_endpoints = {
    address_prefixes = ["10.131.1.0/24"]
    subnet_name      = "snet-pep-lor-qa-centralus"
  }
}

nsg_names = {
  container_apps              = "nsg-app-lor-qa-centralus"
  private_endpoints           = "nsg-pep-kv-lor-qa-centralus"
  database                    = "nsg-db-lor-qa-centralus"
  private_endpoints_openai    = "nsg-pep-openai-lor-qa-centralus"
  private_endpoints_storage   = "nsg-pep-sa-lor-qa-centralus"
}

subnet_nsg_associations = {
  container_apps = {
    nsg_name = "nsg-app-lor-qa-centralus"
  }
  database = {
    nsg_name = "nsg-db-lor-qa-centralus"
  }
  private_endpoints = {
    nsg_name = "nsg-pep-kv-lor-qa-centralus"
  }
}

tags = {
  environment = "qa"
  env_region  = "centralus"
  owner       = "brian.marsh@loresse.ai"
  App         = "acadev"
}

acr_config = {
  name                = "acraioslordevcentralus"
}

existing_acr_config = {
  name                = "acraioslordevcentralus"
  resource_group_name = "rg-cae-aios-dev-centralus"
  subscription_id     = "721c94df-85be-4cea-b741-92f804511633"
}

image_config = {
  login = {
    image  = "backend"
    digest = "f103b6caa985f7b256253d9ccecbe1c41691c6543833b9da4e9596e047f2d19e"
  }
  ui = {
    image  = "ui"
    digest = "1853e17628c2a5d95cde9f63bbf81601747a28731977fc90c603bd4718db2eb7"
  }
  api = {
    image  = "api"
    digest = "5b6412ed6a0dccbf87924f0e2de2765e653adcfbdfacc4b8f34d3648249530af"
  }
}
