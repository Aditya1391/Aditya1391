terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.63.0"
    }
    time = {
      source  = "hashicorp/time"
      version = "~> 0.12"
    }
  }
}

provider "azurerm" {
  features {

  }
  # subscription_id = "69beffef-acb9-4f11-b7d5-7cba2b6d7b28"
  tenant_id       = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"

}

provider "azurerm" {
  alias           = "acr"
  features {}
  subscription_id = var.existing_acr_config.subscription_id
  tenant_id       = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"
}