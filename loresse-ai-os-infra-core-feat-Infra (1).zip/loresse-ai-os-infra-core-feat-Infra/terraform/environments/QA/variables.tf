variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "centralus"
}
variable "resource_group_names" {
  description = "Names for resource groups"
  type        = map(string)
  default = {
    container_env       = "rg-cae-aios-qa-centralus"
    keyvault            = "rg-kv-aios-qa-centralus"
    openai              = "rg-openai-aios-qa-centralus"
    email_communication = "rg-ecs-aios-qa-centralus"
    communication       = "rg-comms-aios-qa-centralus"
    database            = "rg-psql-aios-qa-centralus"
    storage             = "rg-st-aios-qa-centralus"
  }
}

variable "container_apps_config" {
  description = "Container Apps configuration"
  type = object({
    env_name = string
    apps     = map(string)
  })
}

variable "managed_identity_config" {
  description = "Managed Identity configuration"
  type = object({
    name = string
  })
}

variable "keyvault_config" {
  description = "Key Vault configuration"
  type = object({
    kv_name               = string
    private_endpoint_name = optional(string, "")
    rbac_authorization_enabled = optional(bool, false)
  })
}

variable "openai_config" {
  description = "OpenAI configuration"
  type = object({
    name                  = string
    private_endpoint_name = optional(string, "")
  })
}

variable "ecs_config" {
  description = "Email Communication Service configuration"
  type = object({
    services = map(string)
  })
}

variable "acr_config" {
  description = "Azure Container Registry configuration"
  type = object({
    name = string
  })
  default = {
    name = "acraioslordevcentralus"
  }
}

variable "existing_acr_config" {
  description = "Existing DEV Container Registry configuration to reference"
  type = object({
    name                = string
    resource_group_name = string
    subscription_id     = string
  })
  default = {
    name                = "acraioslordevcentralus"
    resource_group_name = "rg-cae-aios-dev-centralus"
    subscription_id     = "721c94df-85be-4cea-b741-92f804511633"
  }
}

variable "image_config" {
  description = "Container images configuration (supports both tag and digest)"
  type = map(object({
    image  = string
    tag    = optional(string)
    digest = optional(string)
  }))
  default = {
    login = {
      image = "backend"
      tag   = "68"
    }
    ui = {
      image = "ui"
      tag   = "68"
    }
    api = {
      image = "api"
      tag   = "68"
    }
  }
}

variable "communication_config" {
  description = "Communication Service configuration"
  type = object({
    services = map(string)
  })
}

variable "database_config" {
  description = "Database configuration"
  type = object({
    db_name = string
  })
}

variable "storage_config" {
  description = "Storage configuration"
  type = object({
    storage_account_name     = string
    blob_container_name      = optional(string, "")
    private_endpoint_name    = optional(string, "")
  })
}

variable "vnet_config" {
  description = "vnet-app-aios-pre-eastus"
  type = object({
    name                = string
    resource_group_name = string
  })
}

variable "subnet_configs" {
  description = "Subnet configurations for container apps"
  type = map(object({
    address_prefixes = list(string)
    subnet_name      = string
  }))
  default = {
    container_apps = {
      address_prefixes = ["10.131.0.0/24"]
      subnet_name      = "snet-app-lor-qa-centralus"
    }
  }
}

variable "database_subnet_config" {
  description = "Subnet configuration for PostgreSQL database (non-delegated)"
  type = object({
    address_prefixes = list(string)
    subnet_name      = string
  })
  default = {
    address_prefixes = ["10.131.2.0/24"]
    subnet_name      = "snet-db-lor-qa-centralus"
  }
}

variable "private_endpoint_subnet_configs" {
  description = "Subnet configurations for private endpoints"
  type = map(object({
    address_prefixes = list(string)
    subnet_name      = string
  }))
  default = {
    private_endpoints = {
      address_prefixes = ["10.131.1.0/24"]
      subnet_name      = "snet-pep-lor-qa-centralus"
    }
  }
}

variable "nsg_names" {
  description = "Names for Network Security Groups"
  type = object({
    container_apps              = string
    private_endpoints           = string
    database                    = string
    private_endpoints_openai    = optional(string)
    private_endpoints_storage   = optional(string)
  })
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "subnet_nsg_associations" {
  description = "Subnet to NSG associations"
  type = map(object({
    nsg_name = string
  }))
  default = {}
}
