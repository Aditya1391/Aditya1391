terraform {
  backend "azurerm" {
    resource_group_name  = "rg-sa-tfstate-nprd-centralus"
    storage_account_name = "satfstatelornprdcus"
    container_name       = "blobtfstatelorqacus"
    key                  = "qatfstate"
    subscription_id      = "721c94df-85be-4cea-b741-92f804511633"
    tenant_id            = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"
    use_azuread_auth     = true
  }
}
