data "azurerm_virtual_network" "existing" {
  name                = var.vnet_config.name
  resource_group_name = var.vnet_config.resource_group_name
}

data "azurerm_container_registry" "existing_acr" {
  provider            = azurerm.acr
  name                = var.existing_acr_config.name
  resource_group_name = var.existing_acr_config.resource_group_name
}

data "azurerm_client_config" "current" {}

resource "azurerm_resource_provider_registration" "communication" {
  name = "Microsoft.Communication"
}

resource "azurerm_resource_provider_registration" "app" {
  name = "Microsoft.App"
}

locals {
  existing_acr_id           = data.azurerm_container_registry.existing_acr.id
  existing_acr_login_server = data.azurerm_container_registry.existing_acr.login_server

  # Construct storage account resource ID from known values to avoid module output circular dependency
  storage_account_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${var.resource_group_names["storage"]}/providers/Microsoft.Storage/storageAccounts/${var.storage_config.storage_account_name}"
}

module "resource_groups" {
  source               = "../../modules/resource_groups"
  resource_group_names = var.resource_group_names
  location             = var.location
  tags                 = var.tags
}

# ============================================================================
# Network Security Groups (MUST be created FIRST - Required by Azure Policy)
# ============================================================================

resource "azurerm_network_security_group" "container_apps_nsg" {
  name                = var.nsg_names.container_apps
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowAzureLoadBalancer"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "AzureLoadBalancer"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "private_endpoints_nsg" {
  name                = var.nsg_names.private_endpoints
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowVnetInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "database_nsg" {
  name                = var.nsg_names.database
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowVnetInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }
}

# ============================================================================
# Subnets - Created AFTER NSGs exist (depends_on ensures ordering)
# ============================================================================

resource "azurerm_subnet" "container_apps" {
  for_each = var.subnet_configs

  name                 = each.value.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = each.value.address_prefixes

  delegation {
    name = "Microsoft.App.environments"

    service_delegation {
      name = "Microsoft.App/environments"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
      ]
    }
  }

  depends_on = [
    azurerm_network_security_group.container_apps_nsg,
    azurerm_network_security_group.database_nsg
  ]
}

resource "azurerm_subnet" "private_endpoints" {
  for_each = var.private_endpoint_subnet_configs

  name                 = each.value.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = each.value.address_prefixes

  depends_on = [azurerm_network_security_group.private_endpoints_nsg]
}

resource "azurerm_subnet" "database" {
  name                 = var.database_subnet_config.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = var.database_subnet_config.address_prefixes

  depends_on = [azurerm_network_security_group.database_nsg]
}

# ============================================================================
# NSG Associations - Created AFTER subnets and NSGs exist
# ============================================================================

resource "azurerm_subnet_network_security_group_association" "container_apps" {
  subnet_id                 = azurerm_subnet.container_apps["container_apps"].id
  network_security_group_id = azurerm_network_security_group.container_apps_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "private_endpoints" {
  subnet_id                 = azurerm_subnet.private_endpoints["private_endpoints"].id
  network_security_group_id = azurerm_network_security_group.private_endpoints_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "database" {
  subnet_id                 = azurerm_subnet.database.id
  network_security_group_id = azurerm_network_security_group.database_nsg.id
}

resource "azurerm_container_app_environment" "env" {
  name                     = var.container_apps_config.env_name
  location                 = var.location
  resource_group_name      = module.resource_groups.names["container_env"]
  infrastructure_subnet_id = azurerm_subnet.container_apps["container_apps"].id
  internal_load_balancer_enabled = false
  tags                     = var.tags
  depends_on               = [azurerm_resource_provider_registration.app]
}

module "containerapps_login" {
  source              = "../../modules/containerapps"
  resource_group_name = module.resource_groups.names["container_env"]
  location            = var.location
  environment_id      = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_target_port     = 8001
  apps = {
    login = var.container_apps_config.apps["login"]
  }
  managed_identity_id = module.qa_managed_identity.id
  acr_login_server   = data.azurerm_container_registry.existing_acr.login_server
  acr_name           = data.azurerm_container_registry.existing_acr.name
  acr_admin_username = null
  acr_admin_password = null
  image_config       = var.image_config
  tags                = merge(var.tags, { env_region = var.location })

  depends_on = [time_sleep.wait_for_acr_pull_rbac]
}

module "containerapps_ui" {
  source              = "../../modules/containerapps"
  resource_group_name = module.resource_groups.names["container_env"]
  location            = var.location
  environment_id      = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_target_port     = 8080
  apps = {
    ui = var.container_apps_config.apps["ui"]
  }
  managed_identity_id = module.qa_managed_identity.id
  acr_login_server   = data.azurerm_container_registry.existing_acr.login_server
  acr_name           = data.azurerm_container_registry.existing_acr.name
  acr_admin_username = null
  acr_admin_password = null
  image_config       = var.image_config
  tags                = merge(var.tags, { env_region = var.location })

  depends_on = [time_sleep.wait_for_acr_pull_rbac]
}

module "containerapps_api" {
  source              = "../../modules/containerapps"
  resource_group_name = module.resource_groups.names["container_env"]
  location            = var.location
  environment_id      = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_target_port     = 8002
  apps = {
    api = var.container_apps_config.apps["api"]
  }
  managed_identity_id = module.qa_managed_identity.id
  acr_login_server   = data.azurerm_container_registry.existing_acr.login_server
  acr_name           = data.azurerm_container_registry.existing_acr.name
  acr_admin_username = null
  acr_admin_password = null
  image_config       = var.image_config
  tags                = merge(var.tags, { env_region = var.location })

  depends_on = [time_sleep.wait_for_acr_pull_rbac]
}

module "keyvault" {
  source                     = "../../modules/keyvault"
  resource_group_name        = module.resource_groups.names["keyvault"]
  location                   = var.location
  kv_name                    = var.keyvault_config.kv_name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  private_endpoint_name      = var.keyvault_config.private_endpoint_name
  private_dns_zone_ids       = []
  tags                       = var.tags
}

module "openai" {
  source                     = "../../modules/openai"
  resource_group_name        = module.resource_groups.names["openai"]
  location                   = var.location
  name                       = var.openai_config.name
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  private_endpoint_name      = var.openai_config.private_endpoint_name
  private_dns_zone_ids       = []
  tags                       = merge(var.tags, { env_region = var.location })
}

module "ecs" {
  source              = "../../modules/ecs"
  resource_group_name = module.resource_groups.names["email_communication"]
  location            = var.location
  data_location       = "United States"
  services            = var.ecs_config.services
  tags                = merge(var.tags, { env_region = var.location })
  depends_on          = [azurerm_resource_provider_registration.communication]
}

module "communication" {
  source              = "../../modules/communication"
  resource_group_name = module.resource_groups.names["communication"]
  location            = var.location
  data_location       = "United States"
  services            = var.communication_config.services
  tags                = merge(var.tags, { env_region = var.location })
  depends_on          = [azurerm_resource_provider_registration.communication]
}

module "database" {
  source                     = "../../modules/postgresdb"
  resource_group_name        = module.resource_groups.names["database"]
  location                   = var.location
  db_name                    = var.database_config.db_name
  private_endpoint_subnet_id = azurerm_subnet.database.id
  private_dns_zone_ids       = []
  tags                       = merge(var.tags, { env_region = var.location })
}

module "storage" {
  source               = "../../modules/storage"
  resource_group_name  = module.resource_groups.names["storage"]
  location             = var.location
  storage_account_name = var.storage_config.storage_account_name
  blob_container_name  = var.storage_config.blob_container_name
  tags                 = merge(var.tags, { env_region = var.location })
}

resource "azurerm_private_endpoint" "storage" {
  name                = var.storage_config.private_endpoint_name
  location            = var.location
  resource_group_name = module.resource_groups.names["storage"]
  subnet_id           = azurerm_subnet.private_endpoints["private_endpoints"].id
  tags                 = var.tags

  private_service_connection {
    name                           = "storage-connection"
    private_connection_resource_id = local.storage_account_id
    is_manual_connection           = false
    subresource_names              = ["blob"]
  }

  depends_on = [module.storage]
}

# Create a new managed identity for QA
module "qa_managed_identity" {
  source              = "../../modules/managed_identity"
  name                = "uami-aios-qa-centralus"
  location            = var.location
  resource_group_name = module.resource_groups.names["container_env"]
  tags                = var.tags
}

# Grant AcrPull role to the new QA managed identity for DEV ACR access
resource "azurerm_role_assignment" "qa_acr_pull" {
  provider             = azurerm.acr
  scope                = data.azurerm_container_registry.existing_acr.id
  role_definition_name = "AcrPull"
  principal_id         = module.qa_managed_identity.principal_id
  principal_type       = "ServicePrincipal"

  depends_on = [module.qa_managed_identity]
}

# Allow ACR RBAC propagation before Container Apps attempt image pulls.
resource "time_sleep" "wait_for_acr_pull_rbac" {
  create_duration = "600s"

  depends_on = [azurerm_role_assignment.qa_acr_pull]
}
