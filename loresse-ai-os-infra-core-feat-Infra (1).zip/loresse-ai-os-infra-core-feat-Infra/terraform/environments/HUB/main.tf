data "azurerm_virtual_network" "hub" {
  provider            = azurerm.hub
  name                = var.vnet_name
  resource_group_name = var.vnet_resource_group_name
}

data "azurerm_client_config" "current" {
  provider = azurerm.hub
}

data "azurerm_user_assigned_identity" "app_gateway" {
  provider            = azurerm.hub
  count               = trimspace(var.user_assigned_identity_id) == "" && trimspace(var.user_assigned_identity_name) != "" ? 1 : 0
  name                = var.user_assigned_identity_name
  resource_group_name = var.user_assigned_identity_resource_group_name != "" ? var.user_assigned_identity_resource_group_name : var.resource_group_name
}

data "azurerm_log_analytics_workspace" "app_gateway" {
  provider            = azurerm.hub
  count               = trimspace(var.log_analytics_workspace_id) == "" && trimspace(var.log_analytics_workspace_name) != "" ? 1 : 0
  name                = var.log_analytics_workspace_name
  resource_group_name = var.log_analytics_workspace_resource_group_name != "" ? var.log_analytics_workspace_resource_group_name : var.resource_group_name
}

data "azurerm_private_dns_zone" "custom_domain" {
  provider            = azurerm.hub
  count               = trimspace(var.custom_private_dns_zone_name) != "" && trimspace(var.custom_private_dns_record_name) != "" ? 1 : 0
  name                = var.custom_private_dns_zone_name
  resource_group_name = trimspace(var.custom_private_dns_zone_resource_group_name) != "" ? var.custom_private_dns_zone_resource_group_name : var.vnet_resource_group_name
}

locals {
  # Use an existing subnet when supplied; otherwise the stack creates the dedicated subnet.
  create_subnet        = var.subnet_id == ""
  effective_subnet_id  = var.subnet_id != "" ? var.subnet_id : azurerm_subnet.app_gateway[0].id
  backend_ui_is_ip     = can(regex("^[0-9]+(\\.[0-9]+){3}$", var.backend_ui_address))
  backend_api_is_ip    = can(regex("^[0-9]+(\\.[0-9]+){3}$", var.backend_api_address))
  backend_langfuse_is_ip = var.backend_langfuse_address != "" ? can(regex("^[0-9]+(\\.[0-9]+){3}$", var.backend_langfuse_address)) : false
  backend_host_header  = var.backend_host_header != "" ? var.backend_host_header : var.backend_ui_address
  probe_host_header    = var.health_probe_host != "" ? var.health_probe_host : local.backend_host_header
  normalized_ssl_certificate_key_vault_secret_id = try(trimspace(var.ssl_certificate_key_vault_secret_id), "")
  normalized_ssl_certificate_pfx_base64          = try(trimspace(var.ssl_certificate_pfx_base64), "")
  normalized_ssl_certificate_password            = try(trimspace(var.ssl_certificate_password), "")
  normalized_observability_ssl_certificate_key_vault_secret_id = try(trimspace(var.observability_ssl_certificate_key_vault_secret_id), "")
  effective_user_assigned_identity_id            = trimspace(var.user_assigned_identity_id) != "" ? trimspace(var.user_assigned_identity_id) : try(data.azurerm_user_assigned_identity.app_gateway[0].id, "")
  effective_log_analytics_workspace_id           = trimspace(var.log_analytics_workspace_id) != "" ? trimspace(var.log_analytics_workspace_id) : try(data.azurerm_log_analytics_workspace.app_gateway[0].id, "")
  custom_private_dns_zone_resource_group_name    = trimspace(var.custom_private_dns_zone_resource_group_name) != "" ? var.custom_private_dns_zone_resource_group_name : var.vnet_resource_group_name
  use_key_vault_ssl_certificate = local.normalized_ssl_certificate_key_vault_secret_id != ""
  use_inline_ssl_certificate    = local.normalized_ssl_certificate_pfx_base64 != ""
  use_ssl_certificate           = local.use_key_vault_ssl_certificate || local.use_inline_ssl_certificate
  listener_protocol             = local.use_ssl_certificate ? "Https" : "Http"
  app_gateway_zones             = ["1", "2", "3"]
  base_tags            = { for key, value in var.tags : key => value if lower(key) != "app" }
  tags                 = merge(local.base_tags, {
    environment = lookup(var.tags, "environment", "prd")
    owner       = var.owner
    App         = var.app
    env_region  = var.location
  })
}

# Resource group dedicated to the hub Application Gateway stack.
resource "azurerm_resource_group" "app_gateway" {
  provider = azurerm.hub
  name     = var.resource_group_name
  location = var.location
  tags     = local.tags
}

# Dedicated WAF policy for production so policy changes do not bleed into Dev or QA.
resource "azurerm_web_application_firewall_policy" "prd" {
  provider            = azurerm.hub
  name                = var.waf_policy_name
  location            = var.location
  resource_group_name = azurerm_resource_group.app_gateway.name
  tags                = local.tags

  lifecycle {
    create_before_destroy = true
  }

  policy_settings {
    enabled                     = true
    mode                        = "Detection"
    request_body_check          = true
    file_upload_enforcement     = true
    file_upload_limit_in_mb     = 100
    max_request_body_size_in_kb  = 128
  }

  managed_rules {
    managed_rule_set {
      type    = "OWASP"
      version = "3.2"
    }

    managed_rule_set {
      type    = "Microsoft_BotManagerRuleSet"
      version = "1.0"
    }
  }
}

# Create the dedicated production subnet only when a subnet ID has not been provided.
resource "azurerm_subnet" "app_gateway" {
  count                = local.create_subnet ? 1 : 0
  provider             = azurerm.hub
  name                 = var.subnet_name
  resource_group_name  = var.vnet_resource_group_name
  virtual_network_name = data.azurerm_virtual_network.hub.name
  address_prefixes     = var.subnet_address_prefixes

  delegation {
    name = "appgw-delegation"

    service_delegation {
      name    = "Microsoft.Network/applicationGateways"
      actions = ["Microsoft.Network/virtualNetworks/subnets/join/action"]
    }
  }
}

# Standard public IP for the public HTTPS listener.
resource "azurerm_public_ip" "app_gateway" {
  provider            = azurerm.hub
  name                = "pip-${var.application_gateway_name}"
  location            = var.location
  resource_group_name = azurerm_resource_group.app_gateway.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = local.app_gateway_zones
  tags                = local.tags
}

resource "azurerm_private_dns_a_record" "app_gateway_custom_frontend" {
  provider            = azurerm.hub
  count               = trimspace(var.custom_private_dns_zone_name) != "" && trimspace(var.custom_private_dns_record_name) != "" ? 1 : 0
  name                = var.custom_private_dns_record_name
  zone_name           = data.azurerm_private_dns_zone.custom_domain[0].name
  resource_group_name = local.custom_private_dns_zone_resource_group_name
  ttl                 = var.custom_private_dns_ttl
  records             = [var.private_frontend_ip]
}

# Production WAF_v2 App Gateway with autoscale and HTTPS-only listener.
resource "azurerm_application_gateway" "prd" {
  provider            = azurerm.hub
  name                = var.application_gateway_name
  location            = var.location
  resource_group_name = azurerm_resource_group.app_gateway.name
  firewall_policy_id  = azurerm_web_application_firewall_policy.prd.id
  http2_enabled       = true
  fips_enabled        = false
  force_firewall_policy_association = false
  zones               = local.app_gateway_zones
  tags                = local.tags

  lifecycle {
    precondition {
      condition     = !(local.use_key_vault_ssl_certificate && local.use_inline_ssl_certificate)
      error_message = "Set only one certificate source: ssl_certificate_key_vault_secret_id or ssl_certificate_pfx_base64."
    }

    precondition {
      condition     = !local.use_inline_ssl_certificate || trimspace(local.normalized_ssl_certificate_password) != ""
      error_message = "ssl_certificate_password is required when ssl_certificate_pfx_base64 is provided."
    }

    precondition {
      condition     = !local.use_key_vault_ssl_certificate || local.effective_user_assigned_identity_id != ""
      error_message = "Set user_assigned_identity_id or user_assigned_identity_name when ssl_certificate_key_vault_secret_id is used."
    }

    precondition {
      condition     = length(var.listener_host_names) > 0
      error_message = "listener_host_names must include at least one production host name."
    }
  }

  sku {
    name = "WAF_v2"
    tier = "WAF_v2"
  }

  autoscale_configuration {
    min_capacity = 1
    max_capacity = 5
  }

  dynamic "identity" {
    for_each = local.effective_user_assigned_identity_id != "" ? [1] : []
    content {
      type         = "UserAssigned"
      identity_ids = [local.effective_user_assigned_identity_id]
    }
  }

  gateway_ip_configuration {
    name      = "appGatewayIpConfig"
    subnet_id = local.effective_subnet_id
  }

  frontend_port {
    name = "port_443"
    port = 443
  }

  frontend_port {
    name = "port_9443"
    port = 9443
  }

  frontend_ip_configuration {
    name                 = "appGwPublicFrontendIpIPv4"
    public_ip_address_id = azurerm_public_ip.app_gateway.id
  }

  frontend_ip_configuration {
    name                          = "appGwPrivateFrontendIpIPv4"
    subnet_id                     = local.effective_subnet_id
    private_ip_address            = var.private_frontend_ip
    private_ip_address_allocation = "Static"
  }

  dynamic "ssl_certificate" {
    for_each = local.use_key_vault_ssl_certificate ? [1] : []
    content {
      name                = "ssl-cert-uat-loresse-ai"
      key_vault_secret_id = local.normalized_ssl_certificate_key_vault_secret_id
    }
  }

  dynamic "ssl_certificate" {
    for_each = local.use_inline_ssl_certificate ? [1] : []
    content {
      name     = "ssl-cert-uat-loresse-ai"
      data     = local.normalized_ssl_certificate_pfx_base64
      password = local.normalized_ssl_certificate_password
    }
  }

  dynamic "ssl_certificate" {
    for_each = local.normalized_observability_ssl_certificate_key_vault_secret_id != "" ? [1] : []
    content {
      name                = "ssl-cert-observability"
      key_vault_secret_id = local.normalized_observability_ssl_certificate_key_vault_secret_id
    }
  }

  backend_address_pool {
    name         = "be-aca-aios-lor-prd-centralus-ui"

    fqdns        = local.backend_ui_is_ip ? null : [var.backend_ui_address]
    ip_addresses = local.backend_ui_is_ip ? [var.backend_ui_address] : null
  }

  backend_address_pool {
    name         = "be-aca-aios-lor-prd-centralus-api"

    fqdns        = local.backend_api_is_ip ? null : [var.backend_api_address]
    ip_addresses = local.backend_api_is_ip ? [var.backend_api_address] : null
  }

  backend_address_pool {
    name         = "be-aca-aios-lor-prd-centralus-lfwe"

    fqdns        = (var.backend_langfuse_address != "" && !local.backend_langfuse_is_ip) ? [var.backend_langfuse_address] : null
    ip_addresses = (var.backend_langfuse_address != "" && local.backend_langfuse_is_ip) ? [var.backend_langfuse_address] : null
  }

  probe {
    name                                      = "backend-aios-lor-prd-centralus-uide0d3ac4-0ad6-4f4f-946f-f5dbf6_"
    protocol                                  = "Https"
    path                                      = "/"
    interval                                  = 30
    timeout                                   = 60
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = true
    minimum_servers                           = 0
    port                                      = 443
    host                                      = null

    match {
      status_code = ["200-399"]
    }
  }

  probe {
    name                                      = "health_probe_http"
    protocol                                  = "Http"
    path                                      = "/"
    interval                                  = 30
    timeout                                   = 60
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = true
    minimum_servers                           = 0
    port                                      = 80
    host                                      = null

    match {
      body        = ""
      status_code = ["200-500"]
    }
  }

  probe {
    name                                      = "health_probe_https_custom"
    protocol                                  = "Https"
    path                                      = "/"
    interval                                  = 30
    timeout                                   = 60
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = true
    minimum_servers                           = 0
    host                                      = null

    match {
      status_code = ["200-399"]
    }
  }

  probe {
    name                                      = "health_probe_https_custom_api"
    protocol                                  = "Https"
    path                                      = "/"
    interval                                  = 30
    timeout                                   = 60
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = true
    minimum_servers                           = 0
    host                                      = null

    match {
      body        = ""
      status_code = ["200-500"]
    }
  }

  probe {
    name                                      = "health_probe_https_custom_gui"
    protocol                                  = "Https"
    path                                      = "/"
    interval                                  = 30
    timeout                                   = 60
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = true
    minimum_servers                           = 0
    host                                      = null

    match {
      body        = ""
      status_code = ["200-399"]
    }
  }

  probe {
    name                                      = "health_probe_tcp_80"
    protocol                                  = "Http"
    path                                      = "/"
    interval                                  = 30
    timeout                                   = 60
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = false
    minimum_servers                           = 0
    port                                      = 80
    host                                      = local.probe_host_header

    match {
      body        = ""
      status_code = ["200-399"]
    }
  }

  probe {
    name                                      = "health_probe_https_custom_lfwe"
    protocol                                  = "Https"
    path                                      = "/"
    interval                                  = 30
    timeout                                   = 30
    unhealthy_threshold                       = 3
    pick_host_name_from_backend_http_settings = true
    minimum_servers                           = 0
    port                                      = 443
    host                                      = null

    match {
      status_code = ["200-399"]
    }
  }

  backend_http_settings {
    name                                 = "be-aca-aios-lor-prd-centralus-api"
    affinity_cookie_name                 = "ApplicationGatewayAffinity"
    cookie_based_affinity                = "Disabled"
    dedicated_backend_connection_enabled = false
    host_name                            = null
    path                                 = null
    pick_host_name_from_backend_address  = true
    port                                 = 443
    probe_name                           = "health_probe_https_custom_api"
    protocol                             = "Https"
    request_timeout                      = 60
    trusted_root_certificate_names       = []
  }

  backend_http_settings {
    name                                 = "be-aca-aios-lor-prd-centralus-ui"
    affinity_cookie_name                 = "ApplicationGatewayAffinity"
    cookie_based_affinity                = "Disabled"
    dedicated_backend_connection_enabled = false
    host_name                            = null
    path                                 = null
    pick_host_name_from_backend_address  = true
    port                                 = 443
    probe_name                           = "health_probe_https_custom_gui"
    protocol                             = "Https"
    request_timeout                      = 60
    trusted_root_certificate_names       = []
  }

  backend_http_settings {
    name                                 = "be-aca-aios-lor-prd-centralus-lfwe"
    affinity_cookie_name                 = "ApplicationGatewayAffinity"
    cookie_based_affinity                = "Disabled"
    dedicated_backend_connection_enabled = false
    host_name                            = null
    path                                 = null
    pick_host_name_from_backend_address  = true
    port                                 = 443
    probe_name                           = "health_probe_https_custom_lfwe"
    protocol                             = "Https"
    request_timeout                      = 60
    trusted_root_certificate_names       = []
  }

  http_listener {
    name                           = "agw-list-external-hub-lor-prd-centralus-https"
    frontend_ip_configuration_name = "appGwPublicFrontendIpIPv4"
    frontend_port_name             = "port_443"
    protocol                       = local.listener_protocol
    require_sni                    = local.use_ssl_certificate ? true : null
    ssl_certificate_name           = local.use_ssl_certificate ? "ssl-cert-uat-loresse-ai" : null
    host_names                     = var.listener_host_names
  }

  http_listener {
    name                           = "agw-list-internal-hub-lor-prd-centralus-https"
    frontend_ip_configuration_name = "appGwPrivateFrontendIpIPv4"
    frontend_port_name             = "port_443"
    protocol                       = local.listener_protocol
    require_sni                    = local.use_ssl_certificate ? true : null
    ssl_certificate_name           = local.use_ssl_certificate ? "ssl-cert-uat-loresse-ai" : null
    host_names                     = var.listener_host_names
  }

  http_listener {
    name                           = "agw-list-langfuse-hub-lor-prd-centralus-https"
    frontend_ip_configuration_name = "appGwPublicFrontendIpIPv4"
    frontend_port_name             = "port_443"
    protocol                       = "Https"
    require_sni                    = true
    ssl_certificate_name           = "ssl-cert-observability"
    host_names                     = var.observability_listener_host_names
  }



  rewrite_rule_set {
    name = "rewrite-strip-prefix"

    rewrite_rule {
      name          = "prdgui-rewrite"
      rule_sequence = 100

      condition {
        variable    = "var_uri_path"
        pattern     = "/api/(.*)"
        ignore_case = true
        negate      = false
      }

      url {
        path         = "{var_uri_path_1}"
        query_string = ""
        reroute      = false
        components   = "path_only"
      }
    }
  }

    url_path_map {
      name                                = "lor-rr-ext-agw-prod-hub-cus"
      default_backend_address_pool_name   = "be-aca-aios-lor-prd-centralus-ui"
      default_backend_http_settings_name  = "be-aca-aios-lor-prd-centralus-ui"

      path_rule {
        name                       = "prd-ext-api"
        paths                      = ["/api/*"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-api"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-api"
        rewrite_rule_set_name      = "rewrite-strip-prefix"
      }

      path_rule {
        name                       = "prd-ext-gui"
        paths                      = ["/gui/*"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-ui"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-ui"
      }

      path_rule {
        name                       = "prd-api-exact"
        paths                      = ["/api"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-api"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-api"
        rewrite_rule_set_name      = "rewrite-strip-prefix"
      }

      path_rule {
        name                       = "prd-gui-exact"
        paths                      = ["/gui"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-ui"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-ui"
      }
    }

    url_path_map {
      name                                = "lor-rr-int-agw-prod-hub-cus"
      default_backend_address_pool_name   = "be-aca-aios-lor-prd-centralus-ui"
      default_backend_http_settings_name  = "be-aca-aios-lor-prd-centralus-ui"

      path_rule {
        name                       = "prd-api-exact"
        paths                      = ["/api"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-api"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-api"
        rewrite_rule_set_name      = "rewrite-strip-prefix"
      }

      path_rule {
        name                       = "prdapi"
        paths                      = ["/api/*"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-api"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-api"
        rewrite_rule_set_name      = "rewrite-strip-prefix"
      }

      path_rule {
        name                       = "prd-gui-exact"
        paths                      = ["/gui"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-ui"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-ui"
      }

      path_rule {
        name                       = "prdgui"
        paths                      = ["/gui/*"]
        backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-ui"
        backend_http_settings_name = "be-aca-aios-lor-prd-centralus-ui"
      }
    }

    request_routing_rule {
      name              = "lor-rr-int-agw-prod-hub-cus"
      rule_type         = "PathBasedRouting"
      http_listener_name = "agw-list-internal-hub-lor-prd-centralus-https"
      url_path_map_name = "lor-rr-int-agw-prod-hub-cus"
      priority          = 120
    }

    request_routing_rule {
      name              = "lor-rr-ext-agw-prod-hub-cus"
      rule_type         = "PathBasedRouting"
      http_listener_name = "agw-list-external-hub-lor-prd-centralus-https"
      url_path_map_name = "lor-rr-ext-agw-prod-hub-cus"
      priority          = 130
    }

    request_routing_rule {
      name                       = "lor-rr-lfwe-agw-prod-hub-cus"
      rule_type                  = "Basic"
      http_listener_name         = "agw-list-langfuse-hub-lor-prd-centralus-https"
      backend_address_pool_name  = "be-aca-aios-lor-prd-centralus-lfwe"
      backend_http_settings_name = "be-aca-aios-lor-prd-centralus-lfwe"
      priority                   = 140
    }


}

# Emit diagnostics to Log Analytics so access, firewall, and performance logs are retained centrally.
resource "azurerm_monitor_diagnostic_setting" "app_gateway" {
  provider                   = azurerm.hub
  count                      = local.effective_log_analytics_workspace_id != "" ? 1 : 0
  name                       = "diag-${var.application_gateway_name}"
  target_resource_id         = azurerm_application_gateway.prd.id
  log_analytics_workspace_id = local.effective_log_analytics_workspace_id

  enabled_log {
    category = "ApplicationGatewayAccessLog"
  }

  enabled_log {
    category = "ApplicationGatewayFirewallLog"
  }

  enabled_log {
    category = "ApplicationGatewayPerformanceLog"
  }

  enabled_metric {
    category = "AllMetrics"
  }
}