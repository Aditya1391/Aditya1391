terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.63.0"
    }
  }
}

# Default provider stays on the hub subscription for local convenience.
provider "azurerm" {
  features        {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}

# Explicit hub alias is used by all hub-scoped resources and data sources.
provider "azurerm" {
  alias           = "hub"
  features        {}
  subscription_id = var.subscription_id
  tenant_id       = var.tenant_id
}