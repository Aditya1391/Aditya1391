terraform {
  backend "azurerm" {
    resource_group_name  = "rg-sa-tfstate-prd-centralus"
    storage_account_name = "satfstatelorprdcus"
    container_name       = "blobtfstatehubprdcus"
    key                  = "hubtfstate"
    subscription_id      = "2aaab541-fd35-4c3f-9836-fa15f85865fc"
    tenant_id            = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"
    use_azuread_auth     = true
  }
}