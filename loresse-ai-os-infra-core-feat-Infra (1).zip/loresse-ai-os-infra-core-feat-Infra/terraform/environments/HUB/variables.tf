variable "subscription_id" {
  description = "Hub subscription ID that owns the shared production Application Gateway"
  type        = string
}

variable "tenant_id" {
  description = "Azure AD tenant ID used by the provider"
  type        = string
}

variable "resource_group_name" {
  description = "Resource group that will contain the production Application Gateway"
  type        = string
  default     = "rg-network-hub-prd-centralus"
}

variable "location" {
  description = "Azure region for the hub Application Gateway"
  type        = string
  default     = "centralus"
}

variable "application_gateway_name" {
  description = "Name of the production Application Gateway"
  type        = string
  default     = "agw-aios-prd-centralus"
}

variable "vnet_name" {
  description = "Existing hub VNet name"
  type        = string
  default     = "vnet-hub-lor-prod-centralus"
}

variable "vnet_resource_group_name" {
  description = "Resource group that contains the hub VNet"
  type        = string
  default     = "rg-vnet-hub-prod-centralus"
}

variable "subnet_id" {
  description = "Optional existing dedicated App Gateway subnet ID; leave blank to create one"
  type        = string
  default     = ""
}

variable "subnet_name" {
  description = "Dedicated subnet name for the production Application Gateway"
  type        = string
  default     = "snet-agw-hub-lor-prd-centralus"
}

variable "subnet_address_prefixes" {
  description = "Address prefixes for the dedicated App Gateway subnet"
  type        = list(string)
  default     = ["10.101.4.0/24"]
}

variable "private_frontend_ip" {
  description = "Static private frontend IP for the internal Application Gateway listener"
  type        = string
  default     = "10.101.5.10"
}

variable "waf_policy_name" {
  description = "Name of the production WAF policy"
  type        = string
  default     = "waf-agw-aios-prd-centralus"
}

variable "ssl_certificate_key_vault_secret_id" {
  description = "Key Vault secret ID for the SSL certificate used by the HTTPS listener"
  type        = string
  default     = ""
  nullable    = true

  validation {
    condition = var.ssl_certificate_key_vault_secret_id == null || var.ssl_certificate_key_vault_secret_id == "" || can(regex("^https://[A-Za-z0-9-]+\\.[A-Za-z0-9.-]+/secrets/[A-Za-z0-9-]+(?:/[A-Za-z0-9]+)?$", var.ssl_certificate_key_vault_secret_id))
    error_message = "ssl_certificate_key_vault_secret_id must be empty or a valid Key Vault secret URI such as https://myvault.vault.azure.net/secrets/my-cert or https://myvault.vault.azure.net/secrets/my-cert/<version>."
  }
}

variable "ssl_certificate_pfx_base64" {
  description = "Optional base64-encoded PFX certificate for the HTTPS listener when Key Vault is not used"
  type        = string
  default     = ""
  sensitive   = true
}

variable "ssl_certificate_password" {
  description = "Optional password for the base64-encoded PFX certificate"
  type        = string
  default     = ""
  sensitive   = true
}

variable "observability_ssl_certificate_key_vault_secret_id" {
  description = "Key Vault secret ID for the observability SSL certificate used by the lfwe listener"
  type        = string
  default     = ""
  nullable    = true

  validation {
    condition = var.observability_ssl_certificate_key_vault_secret_id == null || var.observability_ssl_certificate_key_vault_secret_id == "" || can(regex("^https://[A-Za-z0-9-]+\\.[A-Za-z0-9.-]+/(secrets|certificates)/[A-Za-z0-9-]+(?:/[A-Za-z0-9]+)?$", var.observability_ssl_certificate_key_vault_secret_id))
    error_message = "observability_ssl_certificate_key_vault_secret_id must be empty or a valid Key Vault secret/certificate URI."
  }
}

variable "backend_ui_address" {
  description = "UI backend target address for the Application Gateway; can be an FQDN or private IP"
  type        = string
  default     = "aca-ui.internal.example.com"

  validation {
    condition     = trimspace(var.backend_ui_address) != "" && lower(trimspace(var.backend_ui_address)) != "placeholder.local"
    error_message = "backend_ui_address must be set to a real ACA/FQDN or private IP and cannot be placeholder.local."
  }
}

variable "backend_api_address" {
  description = "API backend target address for the Application Gateway; can be an FQDN or private IP"
  type        = string
  default     = "aca-api.internal.example.com"

  validation {
    condition     = trimspace(var.backend_api_address) != "" && lower(trimspace(var.backend_api_address)) != "placeholder.local"
    error_message = "backend_api_address must be set to a real ACA/FQDN or private IP and cannot be placeholder.local."
  }
}

variable "backend_langfuse_address" {
  description = "Langfuse (lfwe) backend target address for the Application Gateway; can be an FQDN or private IP"
  type        = string
  default     = ""

  validation {
    condition     = trimspace(var.backend_langfuse_address) == "" || lower(trimspace(var.backend_langfuse_address)) != "placeholder.local"
    error_message = "backend_langfuse_address must be a real ACA/FQDN or private IP, not placeholder.local."
  }
}

variable "backend_host_header" {
  description = "Optional host header to send to the backend and health probe"
  type        = string
  default     = ""
}

variable "backend_port" {
  description = "Backend port used by the gateway"
  type        = number
  default     = 443
}

variable "backend_protocol" {
  description = "Backend protocol"
  type        = string
  default     = "Https"
}

variable "health_probe_path" {
  description = "Health probe path"
  type        = string
  default     = "/"
}

variable "health_probe_host" {
  description = "Optional host header for the health probe"
  type        = string
  default     = ""
}

variable "listener_host_names" {
  description = "Optional host names used by the Application Gateway listeners"
  type        = list(string)
  default     = []

  validation {
    condition     = length(var.listener_host_names) > 0
    error_message = "listener_host_names must include at least one production host name."
  }
}

variable "observability_listener_host_names" {
  description = "Optional host names used by the observability/lfwe Application Gateway listener"
  type        = list(string)
  default     = ["observability.loresse.ai"]
}

variable "custom_private_dns_zone_name" {
  description = "Optional existing Private DNS zone used for custom App Gateway frontend host records"
  type        = string
  default     = ""
}

variable "custom_private_dns_zone_resource_group_name" {
  description = "Optional resource group of the existing Private DNS zone; defaults to vnet_resource_group_name when omitted"
  type        = string
  default     = ""
}

variable "custom_private_dns_record_name" {
  description = "Optional Private DNS record label for the App Gateway private frontend IP (for example, 'uat' for uat.loresse.ai)"
  type        = string
  default     = ""
}

variable "custom_private_dns_ttl" {
  description = "TTL in seconds for the optional Private DNS A record"
  type        = number
  default     = 300
}

variable "log_analytics_workspace_id" {
  description = "Log Analytics workspace ID for Application Gateway diagnostics"
  type        = string
  default     = ""

  validation {
    condition = var.log_analytics_workspace_id == "" || (can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.OperationalInsights/workspaces/[^/]+$", trimspace(var.log_analytics_workspace_id))) && !can(regex("<subscription-id>|<rg>|<workspace-name>", var.log_analytics_workspace_id)))
    error_message = "log_analytics_workspace_id must be empty or a real workspace resource ID (no placeholder tokens)."
  }
}

variable "log_analytics_workspace_name" {
  description = "Optional existing Log Analytics workspace name used for Application Gateway diagnostics"
  type        = string
  default     = ""
}

variable "log_analytics_workspace_resource_group_name" {
  description = "Optional resource group for the existing Log Analytics workspace; defaults to resource_group_name when omitted"
  type        = string
  default     = ""
}

variable "user_assigned_identity_id" {
  description = "Optional user-assigned managed identity ID for the Application Gateway"
  type        = string
  default     = ""

  validation {
    condition = var.user_assigned_identity_id == "" || can(regex("^/subscriptions/[^/]+/resourceGroups/[^/]+/providers/Microsoft\\.ManagedIdentity/userAssignedIdentities/[^/]+$", trimspace(var.user_assigned_identity_id)))
    error_message = "user_assigned_identity_id must be empty or a valid managed identity resource ID."
  }
}

variable "user_assigned_identity_name" {
  description = "Optional existing user-assigned managed identity name for the Application Gateway"
  type        = string
  default     = ""
}

variable "user_assigned_identity_resource_group_name" {
  description = "Optional resource group for the existing user-assigned managed identity; defaults to resource_group_name when omitted"
  type        = string
  default     = ""
}

variable "owner" {
  description = "Owner tag value"
  type        = string
  default     = "brian.marsh@loresse.ai"
}

variable "app" {
  description = "Application tag value"
  type        = string
  default     = "acaprd"
}

variable "tags" {
  description = "Additional tags to merge with the production defaults"
  type        = map(string)
  default     = {}
}