output "application_gateway_id" {
  description = "ID of the production Application Gateway"
  value       = azurerm_application_gateway.prd.id
}

output "application_gateway_name" {
  description = "Name of the production Application Gateway"
  value       = azurerm_application_gateway.prd.name
}

output "waf_policy_id" {
  description = "ID of the dedicated production WAF policy"
  value       = azurerm_web_application_firewall_policy.prd.id
}

output "public_ip_id" {
  description = "ID of the App Gateway public IP"
  value       = azurerm_public_ip.app_gateway.id
}

output "subnet_id" {
  description = "Effective subnet ID used by the Application Gateway"
  value       = local.effective_subnet_id
}

output "diagnostic_setting_id" {
  description = "ID of the diagnostic setting attached to the Application Gateway"
  value       = try(azurerm_monitor_diagnostic_setting.app_gateway[0].id, null)
}