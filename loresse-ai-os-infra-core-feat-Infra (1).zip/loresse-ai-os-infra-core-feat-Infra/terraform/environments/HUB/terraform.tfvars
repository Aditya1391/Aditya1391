subscription_id = "2aaab541-fd35-4c3f-9836-fa15f85865fc"
tenant_id       = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"

resource_group_name          = "rg-vnet-hub-prod01-centralus"
location                     = "centralus"
application_gateway_name      = "agw-hub-lor-prod01-centralus"
vnet_name                    = "vnet-hub-lor-prod-centralus"
vnet_resource_group_name     = "rg-vnet-hub-prod-centralus"
subnet_name                  = "snet-agw-hub-lor-prd-centralus"
subnet_address_prefixes      = ["10.101.4.0/24"]
private_frontend_ip          = "10.101.4.10"
waf_policy_name              = "waf-agw-hub-lor-prod01-centralus"
ssl_certificate_key_vault_secret_id = "https://kv-cert-lor-prod-cenus.vault.azure.net/secrets/loresseCertUATConsole"
observability_ssl_certificate_key_vault_secret_id = "https://kv-cert-lor-prod-cenus.vault.azure.net/secrets/observability"
backend_ui_address           = "aca-aios-lor-prd-centralus-ui.thankfulriver-05460092.centralus.azurecontainerapps.io"
backend_api_address          = "aca-aios-lor-prd-centralus-api.thankfulriver-05460092.centralus.azurecontainerapps.io"
backend_langfuse_address     = "aca-aios-lor-prd-centralus-lfwe.thankfulriver-05460092.centralus.azurecontainerapps.io"
backend_host_header          = ""
health_probe_host            = ""
listener_host_names          = ["uat.loresse.ai"]
observability_listener_host_names = ["observability.loresse.ai"]
custom_private_dns_zone_name = ""
custom_private_dns_zone_resource_group_name = ""
custom_private_dns_record_name = ""
custom_private_dns_ttl       = 300
log_analytics_workspace_name = "law-lor-prod-centralus"
log_analytics_workspace_resource_group_name = "rg-mgmt-prod-centralus"
user_assigned_identity_name  = "uami-agw-hub-lor-prod-centralus"
user_assigned_identity_resource_group_name = "rg-vnet-hub-prod-centralus"
owner                        = "brian.marsh@loresse.ai"
app                          = "acaprd"

tags = {
  environment = "prd"
  owner       = "brian.marsh@loresse.ai"
  app         = "acaprd"
  env_region  = "centralus"
}