terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.63.0"
    }
  }
}


provider "azurerm" {
  features {}
  # client_id       = "7b709d80-f8ef-4655-abbe-3fc2871475ec"
  # client_secret   = var.client_secret  # Pass via TF_VAR_client_secret env variable
  tenant_id       = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"
  # subscription_id = "b4a9bbb0-9c2b-4896-8678-ab38d064f226"
}

