variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "centralus"
}
variable "resource_group_names" {
  description = "Names for resource groups"
  type        = map(string)
  default = {
    container_env       = "rg-cae-aios-dev-centralus"
    keyvault            = "rg-kv-aios-dev-centralus"
    openai              = "rg-openai-aios-dev-centralus"
    email_communication = "rg-ecs-aios-dev-centralus"
    communication       = "rg-comms-aios-dev-centralus"
    database            = "rg-psql-aios-dev-centralus"
    storage             = "rg-st-aios-dev-centralus"
    acr                 = "rg-acr-aios-dev-centralus"
  }
}

variable "container_apps_config" {
  description = "Container Apps configuration"
  type = object({
    env_name = string
    apps     = map(string)
  })
}

variable "managed_identity_config" {
  description = "Managed Identity configuration"
  type = object({
    name = string
  })
}

variable "keyvault_config" {
  description = "Key Vault configuration"
  type = object({
    kv_name                    = string
    rbac_authorization_enabled = optional(bool, false)
  })
}

variable "openai_config" {
  description = "OpenAI configuration"
  type = object({
    name = string
  })
}

variable "ecs_config" {
  description = "ECS configuration"
  type = object({
    services = map(string)
  })
}

variable "acr_config" {
  description = "Azure Container Registry configuration"
  type = object({
    name                = string
    resource_group_name = string
  })
  default = {
    name                = "acraioslordevcentralus"
    resource_group_name = "rg-acr-lor-dev-centralus"
  }
}

variable "image_config" {
  description = "Container images configuration"
  type = map(object({
    image = string
    tag   = string
  }))
  default = {
    login = {
      image = "backend"
      tag   = "68"
    }
    ui = {
      image = "ui"
      tag   = "68"
    }
    api = {
      image = "api"
      tag   = "68"
    }
  }
}

variable "communication_config" {
  description = "Communication configuration"
  type = object({
    services = map(string)
  })
}

variable "database_config" {
  description = "Database configuration"
  type = object({
    db_name = string
  })
}

variable "storage_config" {
  description = "Storage configuration"
  type = object({
    storage_account_name = string
    blob_container_name  = optional(string, "")
    blob_container_names = optional(list(string), [])
    allowed_ip_ranges    = optional(list(string), [])
    allowed_subnets      = optional(list(string), [])
  })
}

variable "vnet_config" {
  description = "Existing VNet configuration"
  type = object({
    name                = string
    resource_group_name = string
  })
}

variable "subnet_configs" {
  description = "Subnet configurations for container apps"
  type = map(object({
    address_prefixes = list(string)
    subnet_name      = string
  }))
  default = {
    container_apps = {
      address_prefixes = ["10.121.0.0/24"]
      subnet_name      = "snet-app-lor-dev-centralus"
    }
    database = {
      address_prefixes = ["10.121.2.0/24"]
      subnet_name      = "snet-db-lor-dev-centralus"
    }
  }
}

variable "nsg_names" {
  description = "Names for Network Security Groups"
  type = object({
    container_apps              = string
    private_endpoints           = string
    database                    = optional(string)
    private_endpoints_openai    = optional(string)
    private_endpoints_storage   = optional(string)
  })
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "private_endpoint_subnet_configs" {
  description = "Subnet configurations for private endpoints"
  type = map(object({
    address_prefixes = list(string)
    subnet_name      = string
  }))
  default = {
    private_endpoints = {
      address_prefixes = ["10.121.1.0/24"]
      subnet_name      = "snet-pep-lor-dev-centralus"
    }
  }
}

variable "subnet_nsg_associations" {
  description = "Subnet to NSG associations"
  type = map(object({
    nsg_name = string
  }))
  default = {}
}