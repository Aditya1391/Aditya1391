# terraform {
#   backend "azurerm" {
#     resource_group_name  = "rg-sa-aios-dev-centralus"
#     storage_account_name = "saaioslordevcentralus"
#     container_name       = "devtfstate""qatfstate""prdtfstate"
#     key                  = "dev.tfstate"
#     subscription_id = "721c94df-85be-4cea-b741-92f804511633"
#   }
# }