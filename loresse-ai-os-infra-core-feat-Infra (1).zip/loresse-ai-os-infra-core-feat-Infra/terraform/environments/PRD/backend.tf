terraform {
  backend "azurerm" {
    resource_group_name  = "rg-sa-tfstate-prd-centralus"
    storage_account_name = "satfstatelorprdcus"
    container_name       = "blobtfstatelorprdcus"
    key                  = "prdtfstate"
    subscription_id      = "2fae1784-c860-40d1-8bb5-138aca3dbc03"
    tenant_id            = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"
    use_azuread_auth     = true
  }
}
