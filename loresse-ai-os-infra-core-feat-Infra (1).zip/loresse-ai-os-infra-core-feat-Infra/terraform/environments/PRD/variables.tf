variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "centralus"
}
variable "resource_group_names" {
  description = "Names for resource groups"
  type        = map(string)
  default = {
    container_env       = "rg-cae-aios-prd-centralus"
    keyvault            = "rg-kv-aios-prd-centralus"
    openai              = "rg-openai-aios-prd-centralus"
    email_communication = "rg-ecs-aios-prd-centralus"
    communication       = "rg-comms-aios-prd-centralus"
    database            = "rg-psql-aios-prd-centralus"
    storage             = "rg-sa-aios-prd-centralus"
    redis               = "rg-redis-aios-prd-centralus"
    acr                 = "rg-acr-aios-prd-centralus"
  }
}

variable "container_apps_config" {
  description = "Container Apps configuration"
  type = object({
    env_name                             = string
    apps                                 = map(string)
    public_network_access_enabled        = optional(bool, false)
    private_endpoint_name                = optional(string, "")
    private_dns_zone_name                = optional(string)
    private_dns_zone_resource_group_name = optional(string)
  })
}

variable "managed_identity_config" {
  description = "Managed Identity configuration"
  type = object({
    name = string
  })
}

variable "keyvault_config" {
  description = "Key Vault configuration"
  type = object({
    kv_name                        = string
    private_endpoint_name          = optional(string, "")
    rbac_authorization_enabled     = optional(bool, false)
    public_network_access_enabled  = optional(bool, false)
    network_acls_bypass            = optional(string, "AzureServices")
    network_default_action         = optional(string, "Deny")
    allowed_ip_ranges              = optional(list(string), [])
    allowed_subnet_ids             = optional(list(string), [])
  })
}

variable "openai_config" {
  description = "OpenAI configuration"
  type = object({
    name                          = string
    private_endpoint_name         = optional(string, "")
    public_network_access_enabled = optional(bool, false)
    network_acls_default_action   = optional(string, "Deny")
    network_acls_bypass           = optional(string, "AzureServices")
    allowed_ip_ranges             = optional(list(string), [])
    allowed_subnet_ids            = optional(list(string), [])
  })
}

variable "ecs_config" {
  description = "ECS configuration"
  type = object({
    services = map(string)
  })
}

variable "acr_config" {
  description = "Azure Container Registry configuration"
  type = object({
    name                                 = string
    private_endpoint_name                = optional(string, "pep-acr-lor-prd-centralus")
    private_dns_zone_name                = optional(string, "privatelink.azurecr.io")
    private_dns_zone_resource_group_name = optional(string)
    public_network_access_enabled        = optional(bool, true)
    network_rule_bypass_option           = optional(string, "None")
    network_default_action               = optional(string, "Allow")
    allowed_ip_ranges                    = optional(list(string), [])
    allowed_subnet_ids                   = optional(list(string), [])
  })
  default = {
    name                                 = "acraioslorprdcentralus"
    private_endpoint_name                = "pep-acr-lor-prd-centralus"
    private_dns_zone_name                = "privatelink.azurecr.io"
    private_dns_zone_resource_group_name = "rg-vnet-aios-prd-centralus"
    public_network_access_enabled        = true
    network_rule_bypass_option           = "None"
    network_default_action               = "Allow"
    allowed_ip_ranges                    = []
    allowed_subnet_ids                   = []
  }
}

variable "image_config" {
  description = "Container images configuration (supports both tag and digest)"
  type = map(object({
    image  = string
    tag    = optional(string)
    digest = optional(string)
    cpu    = optional(number, 2)
    memory = optional(string, "4Gi")
  }))
  default = {
    login = {
      image = "backend"
      tag   = "68"
    }
    ui = {
      image = "ui"
      tag   = "68"
    }
    api = {
      image = "api"
      tag   = "68"
    }
  }
}

variable "communication_config" {
  description = "Communication configuration"
  type = object({
    services = map(string)
  })
}

variable "database_config" {
  description = "Database configuration"
  type = object({
    db_name                              = string
    private_endpoint_name                = optional(string, "")
    vnet_integration_enabled             = optional(bool, true)
    create_private_endpoint              = optional(bool, true)
    vnet_private_dns_zone_name           = optional(string, "privatelink.postgres.database.azure.com")
    vnet_private_dns_zone_resource_group = optional(string)
  })
}

variable "storage_config" {
  description = "Storage configuration"
  type = object({
    storage_account_name         = string
    blob_container_name          = optional(string, "")
    file_shares                  = optional(list(object({
      name  = string
      quota = number
    })), [])
    private_endpoint_name        = optional(string)
    allowed_ip_ranges            = optional(list(string), [])
    allowed_subnets              = optional(list(string), [])
    public_network_access_enabled = optional(bool, false)
    network_default_action       = optional(string, "Deny")
    network_bypass               = optional(list(string), ["AzureServices"])
  })
}

variable "redis_config" {
  description = "Azure Managed Redis configuration"
  type = object({
    name                                 = string
    sku_name                             = optional(string, "Balanced_B1")
    minimum_tls_version                  = optional(string, "1.2")
    redis_version                        = optional(string, "7.4")
    clustering_policy                    = optional(string, "EnterpriseCluster")
    high_availability                    = optional(bool, true)
    private_endpoint_name                = optional(string, "")
    private_dns_zone_name                = optional(string, "privatelink.redis.azure.net")
    private_dns_zone_resource_group_name = optional(string)
  })
}

variable "vnet_config" {
  description = "Existing VNet configuration"
  type = object({
    name                = string
    resource_group_name = string
  })
}

variable "subnet_configs" {
  description = "Subnet configurations for container apps"
  type = map(object({
    address_prefixes = list(string)
    subnet_name      = string
  }))
  default = {
    container_apps = {
      address_prefixes = ["10.151.0.0/24"]
      subnet_name      = "snet-app-lor-prd-centralus"
    }
  }
}

variable "database_subnet_config" {
  description = "Subnet configuration for PostgreSQL database (non-delegated)"
  type = object({
    address_prefixes = list(string)
    subnet_name      = string
  })
  default = {
    address_prefixes = ["10.151.2.0/24"]
    subnet_name      = "snet-db-lor-prd-centralus"
  }
}

variable "private_endpoint_subnet_configs" {
  description = "Subnet configurations for private endpoints"
  type = map(object({
    address_prefixes = list(string)
    subnet_name      = string
  }))
  default = {
    private_endpoints = {
      address_prefixes = ["10.151.1.0/24"]
      subnet_name      = "snet-pep-lor-prd-centralus"
    }
  }
}

variable "nsg_names" {
  description = "Names for Network Security Groups"
  type = object({
    container_apps              = string
    private_endpoints           = string
    database                    = string
    private_endpoints_openai    = optional(string)
    private_endpoints_storage   = optional(string)
  })
}

variable "tags" {
  description = "Common tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "subnet_nsg_associations" {
  description = "Subnet to NSG associations"
  type = map(object({
    nsg_name = string
  }))
  default = {}
}
