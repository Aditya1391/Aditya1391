output "app_fqdns" {
  description = "Container App FQDNs keyed by app map key"
  value       = { for app_key, app in azurerm_container_app.apps : app_key => app.latest_revision_fqdn }
}

output "principal_ids" {
  description = "Container App principal IDs keyed by app map key"
  value       = { for app_key, app in azurerm_container_app.apps : app_key => app.identity[0].principal_id }
}
