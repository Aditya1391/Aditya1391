variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "environment_id" { type = string }
variable "apps" { type = map(string) }
variable "managed_identity_id" {
  type    = string
  default = null
}
variable "identity_type" {
  description = "Identity type for container app (SystemAssigned, UserAssigned, or SystemAssigned, UserAssigned)"
  type        = string
  default     = "UserAssigned"

  validation {
    condition     = contains(["SystemAssigned", "UserAssigned", "SystemAssigned, UserAssigned", "SystemAssigned,UserAssigned"], var.identity_type)
    error_message = "identity_type must be SystemAssigned, UserAssigned, or SystemAssigned, UserAssigned."
  }
}
variable "registry_identity" {
  description = "Identity value for registry block (system for SystemAssigned or user-assigned identity resource ID)"
  type        = string
  default     = null
}
variable "acr_login_server" { type = string }
variable "acr_name" { type = string }
variable "acr_admin_username" {
  type    = string
  default = null
}
variable "acr_admin_password" {
  type      = string
  default   = null
  sensitive = true
}

variable "image_config" {
  description = "Container image configuration (image name, tag, digest, cpu, and memory)"
  type = map(object({
    image  = string
    tag    = optional(string)
    digest = optional(string)
    cpu    = optional(number, 2)
    memory = optional(string, "4Gi")
  }))
}

variable "enable_internal_ingress" {
  description = "Enable internal-only HTTP ingress for the container app"
  type        = bool
  default     = false
}

variable "ingress_external_enabled" {
  description = "Whether ingress is reachable outside the Container Apps environment (use true with internal CAE for VNet-limited ingress)"
  type        = bool
  default     = false
}

variable "ingress_target_port" {
  description = "Target container port for ingress when enabled"
  type        = number
  default     = 80
}

variable "min_replicas" {
  description = "Minimum number of replicas for the container app"
  type        = number
  default     = 1
}

variable "tags" {
  description = "Tags to assign to container apps"
  type        = map(string)
  default     = {}
}

variable "volume_mounts" {
  description = "List of Azure File volume mounts to attach to the container"
  type = list(object({
    name       = string
    storage_name = string
    mount_path = string
  }))
  default = []
}
