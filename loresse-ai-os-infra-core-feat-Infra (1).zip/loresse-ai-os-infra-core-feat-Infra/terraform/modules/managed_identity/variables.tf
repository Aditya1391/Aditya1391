variable "name" {
  description = "Name of the managed identity"
  type        = string
}

variable "location" {
  description = "Location"
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name"
  type        = string
}

variable "tags" {
  description = "Tags to assign to managed identity"
  type        = map(string)
  default     = {}
}