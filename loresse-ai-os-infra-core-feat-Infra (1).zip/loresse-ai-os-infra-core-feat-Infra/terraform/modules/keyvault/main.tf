resource "azurerm_key_vault" "kv" {
  name                            = var.kv_name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  tenant_id                       = var.tenant_id
  sku_name                        = "standard"
  tags                            = var.tags
  public_network_access_enabled   = var.public_network_access_enabled
  rbac_authorization_enabled      = var.rbac_authorization_enabled
  enabled_for_deployment          = true
  enabled_for_disk_encryption     = true
  enabled_for_template_deployment = true

  network_acls {
    default_action             = var.network_default_action
    bypass                     = var.network_acls_bypass
    ip_rules                   = var.allowed_ip_ranges
    virtual_network_subnet_ids = var.allowed_subnet_ids
  }
}

module "private_endpoint" {
  source                          = "../private_endpoint"
  name                            = var.private_endpoint_name != "" ? var.private_endpoint_name : "${azurerm_key_vault.kv.name}-pe"
  location                        = var.location
  resource_group_name             = var.resource_group_name
  subnet_id                       = var.private_endpoint_subnet_id
  private_service_connection_name = "keyvault-connection"
  resource_id                     = azurerm_key_vault.kv.id
  subresource_names               = ["vault"]
  private_dns_zone_ids            = var.private_dns_zone_ids
  tags                            = var.tags
}

module "managed_identity" {
  source              = "../managed_identity"
  name                = "${var.kv_name}-mi"
  location            = var.location
  resource_group_name = var.resource_group_name
  tags                = var.tags
}

module "rbac" {
  source = "../rbac"
  role_assignments = {
    keyvault_secrets_user = {
      scope                = azurerm_key_vault.kv.id
      role_definition_name = "Key Vault Secrets User"
      principal_id         = module.managed_identity.principal_id
    }
  }
}
