variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "kv_name" { type = string }
variable "tenant_id" { type = string }
variable "private_endpoint_subnet_id" { type = string }
variable "private_endpoint_name" {
  description = "Custom name for the Key Vault private endpoint"
  type        = string
  default     = ""
}

variable "private_dns_zone_ids" {
  description = "Private DNS zone IDs for Key Vault private endpoint"
  type        = list(string)
  default     = []
}

variable "public_network_access_enabled" {
  description = "Whether Key Vault public network access is enabled"
  type        = bool
  default     = false
}

variable "rbac_authorization_enabled" {
  description = "Whether the Key Vault should use Azure RBAC for data-plane authorization"
  type        = bool
  default     = false
}

variable "network_acls_bypass" {
  description = "Bypass option for Key Vault network ACLs"
  type        = string
  default     = "AzureServices"
}

variable "network_default_action" {
  description = "Default action for Key Vault network ACLs (Allow or Deny)"
  type        = string
  default     = "Deny"
}

variable "allowed_ip_ranges" {
  description = "Public IP CIDR ranges allowed for Key Vault access"
  type        = list(string)
  default     = []
}

variable "allowed_subnet_ids" {
  description = "Subnet IDs allowed for Key Vault access"
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags to apply to key vault"
  type        = map(string)
  default     = {}
}
