variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "redis_name" { type = string }

variable "private_endpoint_name" {
  description = "Custom name for the Redis private endpoint"
  type        = string
  default     = ""
}

variable "private_endpoint_subnet_id" {
  description = "Subnet ID for the Redis private endpoint"
  type        = string
  default     = ""
}

variable "create_private_endpoint" {
  description = "Whether to create a Redis private endpoint"
  type        = bool
  default     = true
}

variable "private_dns_zone_ids" {
  description = "Private DNS zone IDs for Redis private endpoint"
  type        = list(string)
  default     = []
}

variable "sku_name" {
  description = "SKU for Azure Managed Redis (for example Balanced_B1)"
  type        = string
  default     = "Balanced_B1"
}

variable "minimum_tls_version" {
  description = "Minimum TLS version required"
  type        = string
  default     = "1.2"

  validation {
    condition     = contains(["1.0", "1.1", "1.2"], var.minimum_tls_version)
    error_message = "TLS version must be 1.0, 1.1, or 1.2."
  }
}

variable "redis_version" {
  description = "Redis version (e.g. 7.4)"
  type        = string
  default     = "7.4"
}

variable "clustering_policy" {
  description = "Clustering policy for Redis Enterprise"
  type        = string
  default     = "EnterpriseCluster"
}

variable "high_availability" {
  description = "Enable high availability for Redis Enterprise"
  type        = bool
  default     = true
}

variable "tags" {
  description = "Tags to assign to Redis cache"
  type        = map(string)
  default     = {}
}
