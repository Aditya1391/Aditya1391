terraform {
  required_providers {
    azapi = {
      source  = "Azure/azapi"
      version = "~> 2.4"
    }
    azurerm = {
      source = "hashicorp/azurerm"
    }
  }
}

data "azurerm_client_config" "current" {}

locals {
  redis_resource_group_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${var.resource_group_name}"
  # Map clustering policy names to database-level values
  clustering_policy_map = {
    "EnterpriseCluster" = "Enterprise"
    "OSSCluster"        = "OSS"
  }
  database_clustering_policy = lookup(local.clustering_policy_map, var.clustering_policy, replace(var.clustering_policy, "Cluster", ""))
}

resource "azapi_resource" "redis" {
  type      = "Microsoft.Cache/redisEnterprise@2025-07-01"
  name      = var.redis_name
  location  = var.location
  parent_id = local.redis_resource_group_id
  tags      = var.tags

  schema_validation_enabled = false

  body = {
    kind = "v2"
    sku = {
      name = var.sku_name
    }
    identity = {
      type = "SystemAssigned"
    }
    properties = {
      minimumTlsVersion   = var.minimum_tls_version
      publicNetworkAccess = "Disabled"
      redisVersion        = var.redis_version
      clusteringPolicy    = var.clustering_policy
      highAvailability    = var.high_availability ? "Enabled" : "Disabled"
    }
  }

  response_export_values = ["properties.hostName"]
}

resource "azapi_resource" "redis_database" {
  type      = "Microsoft.Cache/redisEnterprise/databases@2025-07-01"
  name      = "default"
  parent_id = azapi_resource.redis.id

  schema_validation_enabled = false

  body = {
    properties = {
      protocol         = "Encryption"
      evictionPolicy   = "NoEviction"
      clustering = {
        policy = local.database_clustering_policy
      }
      highAvailability = var.high_availability ? "Enabled" : "Disabled"
    }
  }

  depends_on = [azapi_resource.redis]
}

module "private_endpoint" {
  source                          = "../private_endpoint"
  count                           = var.create_private_endpoint ? 1 : 0
  name                            = var.private_endpoint_name != "" ? var.private_endpoint_name : "${azapi_resource.redis.name}-pe"
  location                        = var.location
  resource_group_name             = var.resource_group_name
  subnet_id                       = var.private_endpoint_subnet_id
  private_service_connection_name = "redis-connection"
  resource_id                     = azapi_resource.redis.id
  subresource_names               = ["redisEnterprise"]
  private_dns_zone_ids            = var.private_dns_zone_ids
  tags                            = var.tags
}
