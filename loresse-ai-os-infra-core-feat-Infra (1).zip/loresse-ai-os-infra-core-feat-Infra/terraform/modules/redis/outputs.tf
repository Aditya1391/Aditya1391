output "id" {
  description = "Managed Redis resource ID"
  value       = azapi_resource.redis.id
}

output "name" {
  description = "Managed Redis name"
  value       = azapi_resource.redis.name
}

output "hostname" {
  description = "Managed Redis hostname"
  value       = try(jsondecode(azapi_resource.redis.output).properties.hostName, null)
}
