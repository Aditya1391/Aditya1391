variable "role_assignments" {
  description = "Map of role assignments"
  type = map(object({
    scope                = string
    role_definition_name = string
    principal_id         = string
    principal_type       = optional(string)
    skip_service_principal_aad_check = optional(bool)
  }))
}