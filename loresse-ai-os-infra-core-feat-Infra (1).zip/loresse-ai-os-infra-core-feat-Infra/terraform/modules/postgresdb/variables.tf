variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "db_name" { type = string }
variable "private_endpoint_subnet_id" { type = string }

variable "vnet_integration_enabled" {
  description = "Enable VNet-integrated (private access) PostgreSQL Flexible Server"
  type        = bool
  default     = false
}

variable "delegated_subnet_id" {
  description = "Delegated subnet ID for PostgreSQL Flexible Server VNet integration"
  type        = string
  default     = null
}

variable "vnet_private_dns_zone_id" {
  description = "Private DNS zone ID used by VNet-integrated PostgreSQL Flexible Server"
  type        = string
  default     = null
}

variable "create_private_endpoint" {
  description = "Create Private Endpoint for PostgreSQL Flexible Server"
  type        = bool
  default     = true
}

variable "private_endpoint_name" {
  description = "Custom name for PostgreSQL private endpoint"
  type        = string
  default     = ""
}

variable "availability_zone" {
  description = "Availability zone for PostgreSQL (1, 2, or 3). Defaults to 1."
  type        = string
  default     = "1"
}

variable "private_dns_zone_ids" {
  description = "Private DNS zone IDs for PostgreSQL private endpoint"
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags for database resource"
  type        = map(string)
  default     = {}
}
