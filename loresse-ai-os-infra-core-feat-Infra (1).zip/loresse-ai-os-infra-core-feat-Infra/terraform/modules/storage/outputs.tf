output "storage_account_id" {
  value = azurerm_storage_account.storage.id
}

output "storage_account_name" {
  value = azurerm_storage_account.storage.name
}

output "blob_container_id" {
  value = try(values(azurerm_storage_container.blob_container)[0].id, null)
}

output "blob_container_name" {
  value = try(values(azurerm_storage_container.blob_container)[0].name, null)
}

output "blob_container_ids" {
  value = { for k, v in azurerm_storage_container.blob_container : k => v.id }
}

output "primary_access_key" {
  value     = azurerm_storage_account.storage.primary_access_key
  sensitive = true
}

output "blob_container_names" {
  value = [for v in values(azurerm_storage_container.blob_container) : v.name]
}
