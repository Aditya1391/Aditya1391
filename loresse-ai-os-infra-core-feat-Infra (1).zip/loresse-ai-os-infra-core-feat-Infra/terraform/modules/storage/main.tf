resource "azurerm_storage_account" "storage" {
  name                             = var.storage_account_name
  resource_group_name              = var.resource_group_name
  location                         = var.location
  account_tier                     = "Standard"
  account_replication_type         = "LRS"
  tags                             = var.tags
  public_network_access_enabled    = var.public_network_access_enabled

  network_rules {
    default_action             = var.network_default_action
    bypass                     = var.network_bypass
    ip_rules                   = var.allowed_ip_ranges
    virtual_network_subnet_ids = var.allowed_subnets
  }

  identity {
    type = "SystemAssigned"
  }
}

module "rbac" {
  source = "../rbac"
  role_assignments = {
    storage_contributor = {
      scope                = azurerm_storage_account.storage.id
      role_definition_name = "Storage Blob Data Contributor"
      principal_id         = azurerm_storage_account.storage.identity[0].principal_id
    }
  }
}

locals {
  blob_container_names = distinct(compact(concat(
    var.blob_container_name != "" ? [var.blob_container_name] : [],
    var.blob_container_names
  )))
}

resource "azurerm_storage_container" "blob_container" {
  for_each              = toset(local.blob_container_names)
  name                  = each.value
  storage_account_id    = azurerm_storage_account.storage.id
  container_access_type = "private"
}

resource "azurerm_storage_share" "file_share" {
  for_each             = { for share in var.file_shares : share.name => share }
  name                 = each.value.name
  storage_account_id   = azurerm_storage_account.storage.id
  quota                = each.value.quota
}

module "private_endpoint" {
  source                          = "../private_endpoint"
  count                           = var.create_private_endpoint ? 1 : 0
  name                            = var.private_endpoint_name != "" ? var.private_endpoint_name : "${azurerm_storage_account.storage.name}-pe"
  location                        = var.location
  resource_group_name             = var.resource_group_name
  subnet_id                       = var.private_endpoint_subnet_id
  private_service_connection_name = "storage-connection"
  resource_id                     = azurerm_storage_account.storage.id
  subresource_names               = ["blob"]
  private_dns_zone_ids            = var.private_dns_zone_ids
  tags                            = var.tags
}
