variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "storage_account_name" { type = string }
variable "blob_container_name" { 
  type = string
  default = ""
}

variable "blob_container_names" {
  description = "List of blob containers to create in the storage account"
  type        = list(string)
  default     = []
}

variable "file_shares" {
  description = "List of file shares to create in the storage account"
  type = list(object({
    name  = string
    quota = number
  }))
  default = []
}

variable "private_endpoint_name" {
  description = "Custom name for the Storage private endpoint"
  type        = string
  default     = ""
}

variable "private_endpoint_subnet_id" {
  description = "Subnet ID for the Storage private endpoint"
  type        = string
  default     = ""
}

variable "create_private_endpoint" {
  description = "Whether to create a Storage private endpoint"
  type        = bool
  default     = false
}

variable "private_dns_zone_ids" {
  description = "Private DNS zone IDs for Storage private endpoint"
  type        = list(string)
  default     = []
}

variable "allowed_ip_ranges" {
  description = "List of IP ranges to allow access to storage account"
  type        = list(string)
  default     = []
}

variable "allowed_subnets" {
  description = "List of subnet IDs to allow access to storage account"
  type        = list(string)
  default     = []
}

variable "public_network_access_enabled" {
  description = "Whether Storage Account public network access is enabled"
  type        = bool
  default     = false
}

variable "network_default_action" {
  description = "Default action for Storage network rules (Allow or Deny)"
  type        = string
  default     = "Deny"
}

variable "network_bypass" {
  description = "Bypass setting for Storage network rules"
  type        = list(string)
  default     = ["AzureServices"]
}

variable "tags" {
  description = "Optional tags to apply to storage account"
  type        = map(string)
  default     = {}
}
