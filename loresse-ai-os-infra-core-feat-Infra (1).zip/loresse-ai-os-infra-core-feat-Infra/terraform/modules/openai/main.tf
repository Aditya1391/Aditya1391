resource "azurerm_cognitive_account" "openai" {
  name                            = var.name
  location                        = var.location
  resource_group_name             = var.resource_group_name
  kind                            = "OpenAI"
  sku_name                        = "S0"
  tags                            = var.tags
  public_network_access_enabled   = var.public_network_access_enabled
  custom_subdomain_name           = lower(replace(var.name, "-", ""))

  network_acls {
    default_action = var.network_acls_default_action
    bypass         = var.network_acls_bypass
    ip_rules       = var.allowed_ip_ranges

    dynamic "virtual_network_rules" {
      for_each = var.allowed_subnet_ids
      content {
        subnet_id = virtual_network_rules.value
      }
    }
  }

  identity {
    type = "SystemAssigned"
  }
}

module "private_endpoint" {
  source                          = "../private_endpoint"
  name                            = var.private_endpoint_name != "" ? var.private_endpoint_name : "${azurerm_cognitive_account.openai.name}-pe"
  location                        = var.location
  resource_group_name             = var.resource_group_name
  subnet_id                       = var.private_endpoint_subnet_id
  private_service_connection_name = "openai-connection"
  tags                            = var.tags
  resource_id                     = azurerm_cognitive_account.openai.id
  subresource_names               = ["account"]
  private_dns_zone_ids            = var.private_dns_zone_ids
}

module "rbac" {
  source = "../rbac"
  role_assignments = {
    cognitive_services_user = {
      scope                = azurerm_cognitive_account.openai.id
      role_definition_name = "Cognitive Services User"
      principal_id         = azurerm_cognitive_account.openai.identity[0].principal_id
    }
  }
}
