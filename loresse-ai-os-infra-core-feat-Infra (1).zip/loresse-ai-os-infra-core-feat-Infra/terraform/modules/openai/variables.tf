variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "name" { type = string }
variable "private_endpoint_subnet_id" { type = string }
variable "private_endpoint_name" {
  description = "Custom name for the OpenAI private endpoint"
  type        = string
  default     = ""
}

variable "public_network_access_enabled" {
  description = "Whether OpenAI public network access is enabled"
  type        = bool
  default     = false
}

variable "network_acls_default_action" {
  description = "Default action for OpenAI network ACLs"
  type        = string
  default     = "Deny"
}

variable "network_acls_bypass" {
  description = "Bypass option for OpenAI network ACLs"
  type        = string
  default     = "AzureServices"
}

variable "allowed_ip_ranges" {
  description = "Public IP CIDR ranges allowed for OpenAI"
  type        = list(string)
  default     = []
}

variable "allowed_subnet_ids" {
  description = "Subnet IDs allowed for OpenAI network ACLs"
  type        = list(string)
  default     = []
}

variable "private_dns_zone_ids" {
  description = "Private DNS zone IDs for OpenAI private endpoint"
  type        = list(string)
  default     = []
}

variable "tags" {
  description = "Tags to assign to openai account"
  type        = map(string)
  default     = {}
}
