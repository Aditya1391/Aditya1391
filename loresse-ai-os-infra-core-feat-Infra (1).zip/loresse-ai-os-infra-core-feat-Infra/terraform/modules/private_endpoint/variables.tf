variable "name" {
  description = "Name of the private endpoint"
  type        = string
}

variable "location" {
  description = "Location of the private endpoint"
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name"
  type        = string
}

variable "subnet_id" {
  description = "Subnet ID for the private endpoint"
  type        = string
}

variable "tags" {
  description = "Tags to assign to private endpoint"
  type        = map(string)
  default     = {}
}

variable "private_service_connection_name" {
  description = "Name of the private service connection"
  type        = string
}

variable "resource_id" {
  description = "Resource ID to connect to"
  type        = string
}

variable "subresource_names" {
  description = "Subresource names"
  type        = list(string)
}

variable "private_dns_zone_group_name" {
  description = "Name of private DNS zone group"
  type        = string
  default     = "default"
}

variable "private_dns_zone_ids" {
  description = "Private DNS zone IDs to associate with private endpoint"
  type        = list(string)
  default     = []
}