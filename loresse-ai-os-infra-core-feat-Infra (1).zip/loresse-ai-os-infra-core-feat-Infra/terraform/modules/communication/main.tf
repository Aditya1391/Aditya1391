moved {
  from = azurerm_communication_service.comms
  to   = azurerm_communication_service.communication_service
}

resource "azurerm_communication_service" "communication_service" {
  for_each            = var.services
  name                = each.value
  resource_group_name = var.resource_group_name
  data_location       = var.data_location
  tags                = var.tags
}
