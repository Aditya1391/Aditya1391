variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "services" { type = map(string) }
variable "data_location" {
  description = "Data location geography for Communication Services"
  type        = string
  default     = "United States"
}

variable "tags" {
  description = "Tags for Communication Service"
  type        = map(string)
  default     = {}
}
