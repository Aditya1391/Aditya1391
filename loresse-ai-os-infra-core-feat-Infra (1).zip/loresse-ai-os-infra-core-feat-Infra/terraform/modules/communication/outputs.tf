output "service_ids" {
  description = "Communication Service resource IDs"
  value       = { for k, v in azurerm_communication_service.communication_service : k => v.id }
}