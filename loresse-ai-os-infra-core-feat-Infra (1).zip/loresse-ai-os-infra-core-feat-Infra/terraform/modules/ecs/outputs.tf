output "service_ids" {
  description = "Email Communication Service resource IDs"
  value       = { for k, v in azurerm_email_communication_service.email_communication_service : k => v.id }
}

output "domain_ids" {
  description = "Email Communication Service domain resource IDs"
  value       = { for k, v in azurerm_email_communication_service_domain.domain : k => v.id }
}