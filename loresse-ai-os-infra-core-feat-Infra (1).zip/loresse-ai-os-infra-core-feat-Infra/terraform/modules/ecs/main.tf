resource "azurerm_email_communication_service" "email_communication_service" {
  for_each            = var.services
  name                = each.value
  resource_group_name = var.resource_group_name
  data_location       = var.data_location
  tags                = var.tags
}

resource "azurerm_email_communication_service_domain" "domain" {
  for_each          = azurerm_email_communication_service.email_communication_service
  name              = var.domain_name
  email_service_id  = each.value.id
  domain_management = var.domain_management
  tags              = var.tags
}
