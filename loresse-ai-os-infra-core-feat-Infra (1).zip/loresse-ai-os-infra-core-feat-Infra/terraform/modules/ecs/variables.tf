variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "services" { type = map(string) }
variable "data_location" {
  description = "Data location geography for Email Communication Services"
  type        = string
  default     = "United States"
}

variable "domain_name" {
  description = "Email domain name to create under Email Communication Service"
  type        = string
  default     = "AzureManagedDomain"
}

variable "domain_management" {
  description = "Domain management type for the email domain"
  type        = string
  default     = "AzureManaged"
}

variable "tags" {
  description = "Tags for Email Communication Service"
  type        = map(string)
  default     = {}
}
