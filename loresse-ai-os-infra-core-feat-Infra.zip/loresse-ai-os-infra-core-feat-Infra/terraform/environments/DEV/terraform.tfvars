location = "centralus"
resource_group_names = {
  container_env       = "rg-cae-aios-dev-centralus"
  keyvault            = "rg-kv-aios-dev-centralus"
  openai              = "rg-openai-aios-dev-centralus"
  email_communication = "rg-ecs-aios-dev-centralus"
  communication       = "rg-comms-aios-dev-centralus"
  database            = "rg-psql-aios-dev-centralus"
  storage             = "rg-sa-aios-dev-centralus"
  acr                 = "rg-cae-aios-dev-centralus"
}

container_apps_config = {
  env_name = "cae-aios-lor-dev-centralus"
  apps = {
    login = "aca-aios-lor-dev-centralus-ls"
    ui    = "aca-aios-lor-dev-centralus-ui"
    api   = "aca-aios-lor-dev-centralus-api"
  }
}

managed_identity_config = {
  name = "uami-aios-lor-dev-centralus"
}

keyvault_config = {
  kv_name = "kv-aios-lor-dev-cus"
}

openai_config = {
  name = "openai-aios-lor-dev-centralus"
}

ecs_config = {
  services = {
    email = "ecs-aios-lor-dev-centralus"
  }
}

communication_config = {
  services = {
    communication = "comms-aios-lor-dev-centralus"
  }
}

database_config = {
  db_name = "psql-aios-lor-dev-centralus"
}

storage_config = {
  storage_account_name   = "saaioslordevcus"
  blob_container_name    = ""
  allowed_ip_ranges      = [] # Add GitHub Actions runner IP(s) here or your Terraform client IP
  allowed_subnets        = [] # Add additional subnet IDs if needed
}

vnet_config = {
  name                = "vnet-aios-lor-dev-centralus"
  resource_group_name = "rg-vnet-aios-dev-centralus"
}

subnet_configs = {
  container_apps = {
    address_prefixes = ["10.121.0.0/24"]
    subnet_name      = "snet-app-lor-dev-centralus"
  }
  database = {
    address_prefixes = ["10.121.2.0/24"]
    subnet_name      = "snet-db-lor-dev-centralus"
  }
}

private_endpoint_subnet_configs = {
  private_endpoints = {
    address_prefixes = ["10.121.1.0/24"]
    subnet_name      = "snet-pep-lor-dev-centralus"
  }
}

nsg_names = {
  container_apps              = "nsg-app-lor-dev-centralus"
  private_endpoints           = "nsg-pep-kv-lor-dev-centralus"
  database                    = "nsg-db-lor-dev-centralus"
  private_endpoints_openai    = "nsg-pep-openai-lor-dev-centralus"
  private_endpoints_storage   = "nsg-pep-sa-lor-dev-centralus"
}

subnet_nsg_associations = {
  container_apps = {
    nsg_name = "nsg-app-lor-dev-centralus"
  }
  database = {
    nsg_name = "nsg-db-lor-dev-centralus"
  }
  private_endpoints = {
    nsg_name = "nsg-pep-kv-lor-dev-centralus"
  }
}

tags = {
  environment = "dev"
  env_region  = "centralus"
  owner       = "brian.marsh@loresse.ai"
  App         = "acadev"
}

acr_config = {
  name = "acraioslordevcentralus"
}

image_config = {
  login = {
    image = "library/nginx"
    tag   = "latest"
  }
  ui = {
    image = "library/nginx"
    tag   = "latest"
  }
  api = {
    image = "library/nginx"
    tag   = "latest"
  }
}