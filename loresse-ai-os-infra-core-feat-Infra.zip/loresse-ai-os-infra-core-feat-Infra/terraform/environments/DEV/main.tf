
data "azurerm_virtual_network" "existing" {
  name                = var.vnet_config.name
  resource_group_name = var.vnet_config.resource_group_name
}

data "azurerm_client_config" "current" {}

resource "azurerm_resource_provider_registration" "communication" {
  name = "Microsoft.Communication"
}

resource "azurerm_resource_provider_registration" "app" {
  name = "Microsoft.App"
}

module "resource_groups" {
  source               = "../../modules/resource_groups"
  resource_group_names = var.resource_group_names
  location             = var.location
  tags                 = var.tags
}

# Create new Container Registry for DEV environment
module "acr" {
  source              = "../../modules/acr"
  resource_group_name = module.resource_groups.names["acr"]
  location            = var.location
  acr_name            = var.acr_config.name
  tags                = var.tags
}

# Create managed identity for Container Apps
module "containerapps_mi" {
  source              = "../../modules/managed_identity"
  name                = var.managed_identity_config.name
  location            = var.location
  resource_group_name = module.resource_groups.names["container_env"]
  tags                = var.tags
}

# Grant AcrPull role to managed identity for ACR access (created after managed identity)
resource "azurerm_role_assignment" "acr_pull" {
  scope              = module.acr.id
  role_definition_name = "AcrPull"
  principal_id       = module.containerapps_mi.principal_id

  depends_on = [module.containerapps_mi, module.acr]
}

# ============================================================================
# Network Security Groups (MUST be created FIRST - Required by Azure Policy)
# ============================================================================

resource "azurerm_network_security_group" "container_apps_nsg" {
  name                = var.nsg_names.container_apps
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowAzureLoadBalancer"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "AzureLoadBalancer"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "private_endpoints_nsg" {
  name                = var.nsg_names.private_endpoints
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowVnetInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "database_nsg" {
  name                = var.nsg_names.database
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowVnetInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }
}

# ============================================================================
# Subnets - Created AFTER NSGs exist (depends_on ensures ordering)
# ============================================================================

resource "azurerm_subnet" "container_apps" {
  for_each = var.subnet_configs

  name                 = each.value.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = each.value.address_prefixes

  delegation {
    name = "Microsoft.App.environments"

    service_delegation {
      name = "Microsoft.App/environments"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
      ]
    }
  }

  depends_on = [
    azurerm_network_security_group.container_apps_nsg,
    azurerm_network_security_group.database_nsg
  ]
}

resource "azurerm_subnet" "private_endpoints" {
  for_each = var.private_endpoint_subnet_configs

  name                 = each.value.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = each.value.address_prefixes

  depends_on = [azurerm_network_security_group.private_endpoints_nsg]
}

resource "azurerm_subnet" "database" {
  name                 = var.database_subnet_config.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = var.database_subnet_config.address_prefixes

  depends_on = [azurerm_network_security_group.database_nsg]
}

# ============================================================================
# NSG Associations - Created AFTER subnets and NSGs exist
# ============================================================================

resource "azurerm_subnet_network_security_group_association" "container_apps" {
  subnet_id                 = azurerm_subnet.container_apps["container_apps"].id
  network_security_group_id = azurerm_network_security_group.container_apps_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "private_endpoints" {
  subnet_id                 = azurerm_subnet.private_endpoints["private_endpoints"].id
  network_security_group_id = azurerm_network_security_group.private_endpoints_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "database" {
  subnet_id                 = azurerm_subnet.database.id
  network_security_group_id = azurerm_network_security_group.database_nsg.id
}

resource "azurerm_container_app_environment" "env" {
  name                     = var.container_apps_config.env_name
  location                 = var.location
  resource_group_name      = module.resource_groups.names["container_env"]
  infrastructure_subnet_id = azurerm_subnet.container_apps["container_apps"].id
  internal_load_balancer_enabled = true
  tags                     = var.tags
  depends_on               = [azurerm_resource_provider_registration.app]
}


module "containerapps_login" {
  source              = "../../modules/containerapps"
  resource_group_name = module.resource_groups.names["container_env"]
  location            = var.location
  environment_id      = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_target_port     = 8001
  apps = {
    login = var.container_apps_config.apps["login"]
  }
  managed_identity_id = module.containerapps_mi.id
  acr_login_server   = module.acr.login_server
  acr_name           = module.acr.name
  acr_admin_username = module.acr.admin_username
  acr_admin_password = module.acr.admin_password
  image_config       = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
  depends_on         = [azurerm_role_assignment.acr_pull]
}

module "containerapps_ui" {
  source              = "../../modules/containerapps"
  resource_group_name = module.resource_groups.names["container_env"]
  location            = var.location
  environment_id      = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_target_port     = 8080
  apps = {
    ui = var.container_apps_config.apps["ui"]
  }
  managed_identity_id = module.containerapps_mi.id
  acr_login_server   = module.acr.login_server
  acr_name           = module.acr.name
  acr_admin_username = module.acr.admin_username
  acr_admin_password = module.acr.admin_password
  image_config       = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
  depends_on         = [azurerm_role_assignment.acr_pull]
}

module "containerapps_api" {
  source              = "../../modules/containerapps"
  resource_group_name = module.resource_groups.names["container_env"]
  location            = var.location
  environment_id      = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_target_port     = 8002
  apps = {
    api = var.container_apps_config.apps["api"]
  }
  managed_identity_id = module.containerapps_mi.id
  acr_login_server   = module.acr.login_server
  acr_name           = module.acr.name
  acr_admin_username = module.acr.admin_username
  acr_admin_password = module.acr.admin_password
  image_config       = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
  depends_on         = [azurerm_role_assignment.acr_pull]
}

module "keyvault" {
  source                     = "../../modules/keyvault"
  resource_group_name        = module.resource_groups.names["keyvault"]
  location                   = var.location
  kv_name                    = var.keyvault_config.kv_name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  tags                       = var.tags
}

module "openai" {
  source                     = "../../modules/openai"
  resource_group_name        = module.resource_groups.names["openai"]
  location                   = var.location
  name                       = var.openai_config.name
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  tags                       = merge(var.tags, { env_region = var.location })
}

module "ecs" {
  source              = "../../modules/ecs"
  resource_group_name = module.resource_groups.names["email_communication"]
  location            = var.location
  services            = var.ecs_config.services
  tags                = merge(var.tags, { env_region = var.location })
  depends_on          = [azurerm_resource_provider_registration.communication]
}

module "communication" {
  source              = "../../modules/communication"
  resource_group_name = module.resource_groups.names["communication"]
  location            = var.location
  services            = var.communication_config.services
  tags                = merge(var.tags, { env_region = var.location })
  depends_on          = [azurerm_resource_provider_registration.communication]
}

module "database" {
  source                     = "../../modules/database"
  resource_group_name        = module.resource_groups.names["database"]
  location                   = var.location
  db_name                    = var.database_config.db_name
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  tags                       = merge(var.tags, { env_region = var.location })
}

module "storage" {
  source                     = "../../modules/storage"
  resource_group_name        = module.resource_groups.names["storage"]
  location                   = var.location
  storage_account_name       = var.storage_config.storage_account_name
  blob_container_name        = try(var.storage_config.blob_container_name, "")
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  allowed_ip_ranges          = try(var.storage_config.allowed_ip_ranges, [])
  allowed_subnets            = try(var.storage_config.allowed_subnets, [])
  tags                       = merge(var.tags, { env_region = var.location })
}

