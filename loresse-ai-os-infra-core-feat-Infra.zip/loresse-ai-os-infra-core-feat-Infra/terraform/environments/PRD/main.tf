data "azurerm_virtual_network" "existing" {
  name                = var.vnet_config.name
  resource_group_name = var.vnet_config.resource_group_name
}

data "azurerm_private_dns_zone" "acr" {
  provider            = azurerm.hub
  name                = var.acr_config.private_dns_zone_name
  resource_group_name = var.acr_config.private_dns_zone_resource_group_name
}

data "azurerm_private_dns_zone" "postgres_vnet" {
  provider            = azurerm.hub
  name                = var.database_config.vnet_private_dns_zone_name
  resource_group_name = coalesce(try(var.database_config.vnet_private_dns_zone_resource_group, null), var.vnet_config.resource_group_name)
}

data "azurerm_private_dns_zone" "containerapps_environment" {
  provider            = azurerm.hub
  name                = try(var.container_apps_config.private_dns_zone_name, "privatelink.${var.location}.azurecontainerapps.io")
  resource_group_name = coalesce(try(var.container_apps_config.private_dns_zone_resource_group_name, null), var.vnet_config.resource_group_name)
}

data "azurerm_client_config" "current" {}

resource "azurerm_resource_provider_registration" "communication" {
  name = "Microsoft.Communication"
}

resource "azurerm_resource_provider_registration" "app" {
  name = "Microsoft.App"
}

module "resource_groups" {
  source               = "../../modules/resource_groups"
  resource_group_names = var.resource_group_names
  location             = var.location
  tags                 = var.tags
}

# Create new Container Registry for PRD environment
module "acr" {
  source              = "../../modules/acr"
  resource_group_name = module.resource_groups.names["acr"]
  location            = var.location
  acr_name            = var.acr_config.name
  tags                = var.tags
  public_network_access_enabled = try(var.acr_config.public_network_access_enabled, true)
  network_rule_bypass_option    = try(var.acr_config.network_rule_bypass_option, "None")
  network_default_action        = try(var.acr_config.network_default_action, "Allow")
  network_ip_rules              = try(var.acr_config.allowed_ip_ranges, [])
  network_subnet_ids            = try(var.acr_config.allowed_subnet_ids, [])
}

module "acr_private_endpoint" {
  source                          = "../../modules/private_endpoint"
  name                            = var.acr_config.private_endpoint_name
  location                        = var.location
  resource_group_name             = module.resource_groups.names["acr"]
  subnet_id                       = azurerm_subnet.private_endpoints["private_endpoints"].id
  private_service_connection_name = "acr-connection"
  resource_id                     = module.acr.id
  subresource_names               = ["registry"]
  private_dns_zone_ids            = [data.azurerm_private_dns_zone.acr.id]
  tags                            = merge(var.tags, { env_region = var.location })

  depends_on = [module.acr, azurerm_subnet.private_endpoints]
}

# Create managed identity for Container Apps
module "containerapps_mi" {
  source              = "../../modules/managed_identity"
  name                = var.managed_identity_config.name
  location            = var.location
  resource_group_name = module.resource_groups.names["container_env"]
  tags                = var.tags
}

# ============================================================================
# Network Security Groups (MUST be created FIRST - Required by Azure Policy)
# ============================================================================

resource "azurerm_network_security_group" "container_apps_nsg" {
  name                = var.nsg_names.container_apps
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowAzureLoadBalancer"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "AzureLoadBalancer"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "private_endpoints_nsg" {
  name                = var.nsg_names.private_endpoints
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowVnetInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }
}

resource "azurerm_network_security_group" "database_nsg" {
  name                = var.nsg_names.database
  location            = var.location
  resource_group_name = var.vnet_config.resource_group_name
  tags                = var.tags

  security_rule {
    name                       = "AllowVnetInbound"
    priority                   = 100
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "*"
    source_port_range          = "*"
    destination_port_range     = "*"
    source_address_prefix      = "VirtualNetwork"
    destination_address_prefix = "*"
  }
}

# ============================================================================
# Subnets - Created AFTER NSGs exist (depends_on ensures ordering)
# ============================================================================

resource "azurerm_subnet" "container_apps" {
  for_each = var.subnet_configs

  name                 = each.value.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = each.value.address_prefixes

  delegation {
    name = "Microsoft.App.environments"

    service_delegation {
      name = "Microsoft.App/environments"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
      ]
    }
  }

  depends_on = [
    azurerm_network_security_group.container_apps_nsg,
    azurerm_network_security_group.database_nsg
  ]
}

resource "azurerm_subnet" "private_endpoints" {
  for_each = var.private_endpoint_subnet_configs

  name                 = each.value.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = each.value.address_prefixes
  private_endpoint_network_policies = "Disabled"

  depends_on = [azurerm_network_security_group.private_endpoints_nsg]
}

resource "azurerm_subnet" "database" {
  name                 = var.database_subnet_config.subnet_name
  resource_group_name  = var.vnet_config.resource_group_name
  virtual_network_name = data.azurerm_virtual_network.existing.name
  address_prefixes     = var.database_subnet_config.address_prefixes

  delegation {
    name = "Microsoft.DBforPostgreSQL.flexibleServers"

    service_delegation {
      name = "Microsoft.DBforPostgreSQL/flexibleServers"
      actions = [
        "Microsoft.Network/virtualNetworks/subnets/join/action",
      ]
    }
  }

  depends_on = [azurerm_network_security_group.database_nsg]
}

# ============================================================================
# NSG Associations - Created AFTER subnets and NSGs exist
# ============================================================================

resource "azurerm_subnet_network_security_group_association" "container_apps" {
  subnet_id                 = azurerm_subnet.container_apps["container_apps"].id
  network_security_group_id = azurerm_network_security_group.container_apps_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "private_endpoints" {
  subnet_id                 = azurerm_subnet.private_endpoints["private_endpoints"].id
  network_security_group_id = azurerm_network_security_group.private_endpoints_nsg.id
}

resource "azurerm_subnet_network_security_group_association" "database" {
  subnet_id                 = azurerm_subnet.database.id
  network_security_group_id = azurerm_network_security_group.database_nsg.id
}

resource "azurerm_log_analytics_workspace" "containerapps" {
  name                = "law-aios-lor-prd-centralus"
  location            = var.location
  resource_group_name = module.resource_groups.names["container_env"]
  sku                 = "PerGB2018"
  retention_in_days   = 30
  tags                = merge(var.tags, { env_region = var.location })
}

resource "azurerm_container_app_environment" "env" {
  name                           = var.container_apps_config.env_name
  location                       = var.location
  resource_group_name            = module.resource_groups.names["container_env"]
  infrastructure_subnet_id       = azurerm_subnet.container_apps["container_apps"].id
  log_analytics_workspace_id     = azurerm_log_analytics_workspace.containerapps.id
  internal_load_balancer_enabled = true
  public_network_access          = try(var.container_apps_config.public_network_access_enabled, false) ? "Enabled" : "Disabled"

  identity {
    type = "SystemAssigned"
  }

  tags                           = var.tags
  depends_on                     = [azurerm_resource_provider_registration.app]
}

module "containerapps_environment_private_endpoint" {
  source                          = "../../modules/private_endpoint"
  name                            = try(var.container_apps_config.private_endpoint_name, "") != "" ? var.container_apps_config.private_endpoint_name : "${azurerm_container_app_environment.env.name}-pe"
  location                        = var.location
  resource_group_name             = module.resource_groups.names["container_env"]
  subnet_id                       = azurerm_subnet.private_endpoints["private_endpoints"].id
  private_service_connection_name = "containerapps-environment-connection"
  resource_id                     = azurerm_container_app_environment.env.id
  subresource_names               = ["managedEnvironments"]
  private_dns_zone_ids            = [data.azurerm_private_dns_zone.containerapps_environment.id]
  tags                            = merge(var.tags, { env_region = var.location })

  depends_on = [
    azurerm_container_app_environment.env,
    azurerm_subnet_network_security_group_association.private_endpoints
  ]
}

locals {
  # True means container apps use only system-assigned identity.
  container_apps_system_only = true
  container_apps_identity_type = local.container_apps_system_only ? "SystemAssigned" : "SystemAssigned,UserAssigned"
  container_apps_registry_identity = local.container_apps_system_only ? "system" : module.containerapps_mi.id
  container_apps_managed_identity_id = local.container_apps_system_only ? null : module.containerapps_mi.id
}


module "containerapps_login" {
  source                  = "../../modules/containerapps"
  resource_group_name     = module.resource_groups.names["container_env"]
  location                = var.location
  environment_id          = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_external_enabled = true
  ingress_target_port     = 8001
  apps = {
    login = var.container_apps_config.apps["login"]
  }
  identity_type       = local.container_apps_identity_type
  managed_identity_id = local.container_apps_managed_identity_id
  registry_identity   = local.container_apps_registry_identity
  acr_login_server    = module.acr.login_server
  acr_name            = module.acr.name
  acr_admin_username  = null
  acr_admin_password  = null
  image_config        = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
}

module "containerapps_ui" {
  source                  = "../../modules/containerapps"
  resource_group_name     = module.resource_groups.names["container_env"]
  location                = var.location
  environment_id          = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_external_enabled = true
  ingress_target_port     = 8080
  apps = {
    ui = var.container_apps_config.apps["ui"]
  }
  identity_type       = local.container_apps_identity_type
  managed_identity_id = local.container_apps_managed_identity_id
  registry_identity   = local.container_apps_registry_identity
  acr_login_server    = module.acr.login_server
  acr_name            = module.acr.name
  acr_admin_username  = null
  acr_admin_password  = null
  image_config        = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
}

module "containerapps_api" {
  source                  = "../../modules/containerapps"
  resource_group_name     = module.resource_groups.names["container_env"]
  location                = var.location
  environment_id          = azurerm_container_app_environment.env.id
  enable_internal_ingress = true
  ingress_external_enabled = true
  ingress_target_port     = 8002
  apps = {
    api = var.container_apps_config.apps["api"]
  }
  identity_type       = local.container_apps_identity_type
  managed_identity_id = local.container_apps_managed_identity_id
  registry_identity   = local.container_apps_registry_identity
  acr_login_server    = module.acr.login_server
  acr_name            = module.acr.name
  acr_admin_username  = null
  acr_admin_password  = null
  image_config        = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
}

module "containerapps_lfwe" {
  source                   = "../../modules/containerapps"
  resource_group_name      = module.resource_groups.names["container_env"]
  location                 = var.location
  environment_id           = azurerm_container_app_environment.env.id
  enable_internal_ingress  = true
  ingress_external_enabled = true
  ingress_target_port      = 3000
  apps = {
    lfwe = var.container_apps_config.apps["lfwe"]
  }
  identity_type       = local.container_apps_identity_type
  managed_identity_id = local.container_apps_managed_identity_id
  registry_identity   = local.container_apps_registry_identity
  acr_login_server    = module.acr.login_server
  acr_name            = module.acr.name
  acr_admin_username  = null
  acr_admin_password  = null
  image_config        = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
}

module "containerapps_lfwo" {
  source                   = "../../modules/containerapps"
  resource_group_name      = module.resource_groups.names["container_env"]
  location                 = var.location
  environment_id           = azurerm_container_app_environment.env.id
  enable_internal_ingress  = false
  apps = {
    lfwo = var.container_apps_config.apps["lfwo"]
  }
  identity_type       = local.container_apps_identity_type
  managed_identity_id = local.container_apps_managed_identity_id
  registry_identity   = local.container_apps_registry_identity
  acr_login_server    = module.acr.login_server
  acr_name            = module.acr.name
  acr_admin_username  = null
  acr_admin_password  = null
  image_config        = var.image_config
  tags                = merge(var.tags, { env_region = var.location })
}

locals {
  container_app_principal_ids = merge(
    module.containerapps_login.principal_ids,
    module.containerapps_ui.principal_ids,
    module.containerapps_api.principal_ids,
    module.containerapps_lfwe.principal_ids,
    module.containerapps_lfwo.principal_ids
  )
}

resource "azurerm_role_assignment" "containerapps_acr_pull" {
  for_each                         = local.container_app_principal_ids
  scope                            = module.acr.id
  role_definition_name             = "AcrPull"
  principal_id                     = each.value
  principal_type                   = "ServicePrincipal"
  skip_service_principal_aad_check = true

  depends_on = [
    module.acr,
    module.containerapps_login,
    module.containerapps_ui,
    module.containerapps_api,
    module.containerapps_lfwe,
    module.containerapps_lfwo
  ]
}

module "keyvault" {
  source                     = "../../modules/keyvault"
  resource_group_name        = module.resource_groups.names["keyvault"]
  location                   = var.location
  kv_name                    = var.keyvault_config.kv_name
  tenant_id                  = data.azurerm_client_config.current.tenant_id
  private_endpoint_name      = try(var.keyvault_config.private_endpoint_name, "")
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  rbac_authorization_enabled = try(var.keyvault_config.rbac_authorization_enabled, false)
  public_network_access_enabled = try(var.keyvault_config.public_network_access_enabled, false)
  network_acls_bypass           = try(var.keyvault_config.network_acls_bypass, "AzureServices")
  network_default_action        = try(var.keyvault_config.network_default_action, "Deny")
  allowed_ip_ranges             = try(var.keyvault_config.allowed_ip_ranges, [])
  allowed_subnet_ids            = try(var.keyvault_config.allowed_subnet_ids, [])
  tags                       = var.tags
  depends_on                 = [azurerm_subnet_network_security_group_association.private_endpoints]
}

module "openai" {
  source                     = "../../modules/openai"
  resource_group_name        = module.resource_groups.names["openai"]
  location                   = var.location
  name                       = var.openai_config.name
  private_endpoint_name      = try(var.openai_config.private_endpoint_name, "")
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  public_network_access_enabled = try(var.openai_config.public_network_access_enabled, false)
  network_acls_default_action   = try(var.openai_config.network_acls_default_action, "Deny")
  network_acls_bypass           = try(var.openai_config.network_acls_bypass, "AzureServices")
  allowed_ip_ranges             = try(var.openai_config.allowed_ip_ranges, [])
  allowed_subnet_ids            = try(var.openai_config.allowed_subnet_ids, [])
  tags                       = merge(var.tags, { env_region = var.location })
  depends_on                 = [azurerm_subnet_network_security_group_association.private_endpoints]
}

module "ecs" {
  source              = "../../modules/ecs"
  resource_group_name = module.resource_groups.names["email_communication"]
  location            = var.location
  services            = var.ecs_config.services
  tags                = merge(var.tags, { env_region = var.location })
  depends_on          = [azurerm_resource_provider_registration.communication]
}

module "communication" {
  source              = "../../modules/communication"
  resource_group_name = module.resource_groups.names["communication"]
  location            = var.location
  services            = var.communication_config.services
  tags                = merge(var.tags, { env_region = var.location })
  depends_on          = [azurerm_resource_provider_registration.communication]
}

resource "azurerm_communication_service_email_domain_association" "ecs_domain_connection" {
  communication_service_id = one(values(module.communication.service_ids))
  email_service_domain_id  = one(values(module.ecs.domain_ids))

  depends_on = [module.ecs, module.communication]
}

module "database" {
  source                     = "../../modules/database"
  resource_group_name        = module.resource_groups.names["database"]
  location                   = var.location
  db_name                    = var.database_config.db_name
  vnet_integration_enabled   = try(var.database_config.vnet_integration_enabled, true)
  delegated_subnet_id        = azurerm_subnet.database.id
  vnet_private_dns_zone_id   = data.azurerm_private_dns_zone.postgres_vnet.id
  create_private_endpoint    = try(var.database_config.create_private_endpoint, true)
  private_endpoint_name      = try(var.database_config.private_endpoint_name, "")
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  tags                       = merge(var.tags, { env_region = var.location })
}

module "storage" {
  source               = "../../modules/storage"
  resource_group_name  = module.resource_groups.names["storage"]
  location             = var.location
  storage_account_name = var.storage_config.storage_account_name
  blob_container_name  = try(var.storage_config.blob_container_name, "")
  private_endpoint_name      = try(var.storage_config.private_endpoint_name, "")
  private_endpoint_subnet_id = azurerm_subnet.private_endpoints["private_endpoints"].id
  create_private_endpoint    = true
  allowed_ip_ranges    = try(var.storage_config.allowed_ip_ranges, [])
  allowed_subnets      = try(var.storage_config.allowed_subnets, [])
  public_network_access_enabled = try(var.storage_config.public_network_access_enabled, false)
  network_default_action        = try(var.storage_config.network_default_action, "Deny")
  network_bypass                = try(var.storage_config.network_bypass, ["AzureServices"])
  tags                 = merge(var.tags, { env_region = var.location })
}

