terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "4.74.0"
    }
    time = {
      source  = "hashicorp/time"
      version = "~> 0.12"
    }
  }
}

provider "azurerm" {
  features {}
  subscription_id = "2fae1784-c860-40d1-8bb5-138aca3dbc03"
  tenant_id = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"
}

provider "azurerm" {
  alias           = "hub"
  features        {}
  subscription_id = "2aaab541-fd35-4c3f-9836-fa15f85865fc"
  tenant_id       = "ff926c24-6f2e-4b6b-b0ac-a10af1a8d626"
}
