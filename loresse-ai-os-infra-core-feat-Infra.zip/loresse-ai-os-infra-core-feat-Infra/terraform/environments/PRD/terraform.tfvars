location = "centralus"
resource_group_names = {
  container_env       = "rg-cae-aios-prd-centralus"
  keyvault            = "rg-kv-aios-prd-centralus"
  openai              = "rg-openai-aios-prd-centralus"
  email_communication = "rg-ecs-aios-prd-centralus"
  communication       = "rg-comms-aios-prd-centralus"
  database            = "rg-psql-aios-prd-centralus"
  storage             = "rg-sa-aios-prd-centralus"
  acr                 = "rg-cae-aios-prd-centralus"
}

container_apps_config = {
  env_name = "cae-aios-lor-prd-centralus"
  public_network_access_enabled        = false
  private_endpoint_name                = "pep-cae-lor-prd-centralus"
  private_dns_zone_name                = "privatelink.centralus.azurecontainerapps.io"
  private_dns_zone_resource_group_name = "rg-private-dns-zones-eastus"
  apps = {
    login = "aca-aios-lor-prd-centralus-ls"
    ui    = "aca-aios-lor-prd-centralus-ui"
    api   = "aca-aios-lor-prd-centralus-api"
    lfwe  = "aca-aios-lor-prd-centralus-lfwe"
    lfwo  = "aca-aios-lor-prd-centralus-lfwo"
  }
}

managed_identity_config = {
  name = "uami-aios-lor-prd-centralus"
}

keyvault_config = {
  kv_name                       = "kv-aios-lor-prd-cus"
  private_endpoint_name         = "pep-kv-lor-prd-centralus"
  rbac_authorization_enabled    = true
  public_network_access_enabled = false
  network_acls_bypass           = "AzureServices"
  network_default_action        = "Deny"
  allowed_ip_ranges             = ["104.209.171.72", "20.169.217.80"]
  allowed_subnet_ids            = []
}

openai_config = {
  name                          = "openai-aios-lor-prd-centralus"
  private_endpoint_name         = "pep-openai-lor-prd-centralus"
  public_network_access_enabled = false
  network_acls_default_action   = "Deny"
  network_acls_bypass           = "AzureServices"
  allowed_ip_ranges             = ["104.209.171.72", "20.169.217.80"]
  allowed_subnet_ids            = []
}

ecs_config = {
  services = {
    email = "ecs-aios-lor-prd-centralus"
  }
}

communication_config = {
  services = {
    communication = "comms-aios-lor-prd-centralus"
  }
}

database_config = {
  db_name                              = "psql-aios-lor-prd-centralus"
  private_endpoint_name                = "pep-db-lor-prd-centralus"
  vnet_integration_enabled             = true
  create_private_endpoint              = false
  vnet_private_dns_zone_name           = "privatelink.postgres.database.azure.com"
  vnet_private_dns_zone_resource_group = "rg-private-dns-zones-eastus"
}

storage_config = {
  storage_account_name   = "saaioslorprdcentralus"
  blob_container_name    = "blobaioslorprdcentralus"
  private_endpoint_name  = "pep-sa-aios-lor-prd-centralus"
  public_network_access_enabled = true
  network_default_action = "Deny"
  network_bypass         = ["AzureServices"]
  allowed_ip_ranges      = ["104.209.171.72", "20.169.217.80"]
  allowed_subnets        = [] # Add additional subnet IDs if needed
}

vnet_config = {
  name                = "vnet-aios-lor-prd-centralus"
  resource_group_name = "rg-vnet-aios-prd-centralus"
}

subnet_configs = {
  container_apps = {
    address_prefixes = ["10.151.0.0/24"]
    subnet_name      = "snet-app-lor-prd-centralus"
  }
}

database_subnet_config = {
  address_prefixes = ["10.151.2.0/24"]
  subnet_name      = "snet-db-lor-prd-centralus"
}

private_endpoint_subnet_configs = {
  private_endpoints = {
    address_prefixes = ["10.151.1.0/24"]
    subnet_name      = "snet-pep-lor-prd-centralus"
  }
}

nsg_names = {
  container_apps              = "nsg-app-lor-prd-centralus"
  private_endpoints           = "nsg-pep-kv-lor-prd-centralus"
  database                    = "nsg-db-lor-prd-centralus"
  private_endpoints_openai    = "nsg-pep-openai-lor-prd-centralus"
  private_endpoints_storage   = "nsg-pep-sa-lor-prd-centralus"
}

subnet_nsg_associations = {
  container_apps = {
    nsg_name = "nsg-app-lor-prd-centralus"
  }
  database = {
    nsg_name = "nsg-db-lor-prd-centralus"
  }
  private_endpoints = {
    nsg_name = "nsg-pep-kv-lor-prd-centralus"
  }
}

tags = {
  environment = "prd"
  env_region  = "centralus"
  owner       = "brian.marsh@loresse.ai"
  App         = "acadev"
}

acr_config = {
  name                                 = "acraioslorprdcentralus"
  private_endpoint_name                = "pep-acr-lor-prd-centralus"
  private_dns_zone_name                = "privatelink.azurecr.io"
  private_dns_zone_resource_group_name = "rg-private-dns-zones-eastus"
  public_network_access_enabled        = true
  network_rule_bypass_option           = "None"
  network_default_action               = "Deny"
  allowed_ip_ranges                    = ["104.209.171.72", "20.169.217.80"]
  allowed_subnet_ids                   = [] # Add subnet resource IDs to allow VNet-based access
}

image_config = {
  login = {
    image  = "backend"
    tag    = "v1"
    digest = "sha256:48548610eb9139375599245148cbcf878b997a8df3dea49da2c647c624503ee5"
  }
  ui = {
    image  = "ui"
    tag    = "v1"
    digest = "sha256:615048b83b5e65c85d6c3b7c6ccbcfd31e990da99f29696a510f610781eccf14"
  }
  api = {
    image  = "api"
    tag    = "v1"
    digest = "sha256:9f1c0b366020578b7f035d0208a6bad0b96cb865895f2ba061cdfaa74ac0fbe4"
  }
  lfwe = {
    image  = "langfuse"
    tag    = "1"
    digest = "sha256:550c03c0b3fa2c054edc4691cfcbaebd244654afe367935a48e1eccaddb7f1d5"
  }
  lfwo = {
    image  = "langfuse-worker"
    tag    = "1"
    digest = "sha256:8afc38106a1c27a8f5b978ec6eeed8bf37611e3c5fbbf8b087c985a73e8300fb"
  }
}