resource "azurerm_postgresql_flexible_server" "db" {
  name                   = var.db_name
  resource_group_name    = var.resource_group_name
  location               = var.location
  zone                   = var.availability_zone != null ? var.availability_zone : "1"
  administrator_login    = "pgadmin"
  administrator_password = "SuperSecurePassword123!"
  sku_name               = "B_Standard_B1ms"
  storage_mb             = 32768
  version                = "13"
  tags                   = var.tags
  public_network_access_enabled = false
  delegated_subnet_id    = var.vnet_integration_enabled ? var.delegated_subnet_id : null
  private_dns_zone_id    = var.vnet_integration_enabled ? var.vnet_private_dns_zone_id : null

  identity {
    type = "SystemAssigned"
  }
}

module "rbac" {
  source = "../rbac"
  role_assignments = {
    contributor = {
      scope                = azurerm_postgresql_flexible_server.db.id
      role_definition_name = "Contributor"
      principal_id         = azurerm_postgresql_flexible_server.db.identity[0].principal_id
    }
  }
}
