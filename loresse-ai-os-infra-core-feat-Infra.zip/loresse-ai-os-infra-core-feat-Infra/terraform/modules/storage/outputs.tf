output "storage_account_id" {
  value = azurerm_storage_account.storage.id
}

output "storage_account_name" {
  value = azurerm_storage_account.storage.name
}

output "blob_container_id" {
  value = try(azurerm_storage_container.blob_container[0].id, null)
}

output "blob_container_name" {
  value = try(azurerm_storage_container.blob_container[0].name, null)
}
