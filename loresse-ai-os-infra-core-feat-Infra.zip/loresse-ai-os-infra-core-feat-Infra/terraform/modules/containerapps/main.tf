resource "azurerm_container_app" "apps" {
  for_each                     = var.apps
  name                         = each.value
  resource_group_name          = var.resource_group_name
  container_app_environment_id = var.environment_id
  tags                         = var.tags

  revision_mode = "Single"

  dynamic "ingress" {
    for_each = var.enable_internal_ingress ? [1] : []
    content {
      external_enabled = var.ingress_external_enabled
      target_port      = var.ingress_target_port
      transport        = "auto"

      traffic_weight {
        latest_revision = true
        percentage      = 100
      }
    }
  }

  registry {
    server   = var.acr_login_server
    identity = var.registry_identity != null ? var.registry_identity : (var.identity_type == "SystemAssigned" ? "system" : var.managed_identity_id)
  }

  template {
    container {
      name = each.key
      image = (
        var.image_config[each.key].digest != null
        ? (strcontains(var.image_config[each.key].image, "/")
          ? "${var.image_config[each.key].image}@sha256:${trimprefix(var.image_config[each.key].digest, "sha256:")}"
        : "${var.acr_login_server}/${var.image_config[each.key].image}@sha256:${trimprefix(var.image_config[each.key].digest, "sha256:")}")
        : (strcontains(var.image_config[each.key].image, "/")
          ? "${var.image_config[each.key].image}:${var.image_config[each.key].tag}"
        : "${var.acr_login_server}/${var.image_config[each.key].image}:${var.image_config[each.key].tag}")
      )
      cpu    = 0.25
      memory = "0.5Gi"
    }
  }

  identity {
    type = var.identity_type
    identity_ids = contains(["UserAssigned", "SystemAssigned,UserAssigned"], var.identity_type) ? [
      var.managed_identity_id
    ] : null
  }

  lifecycle {
    precondition {
      condition     = !contains(["UserAssigned", "SystemAssigned,UserAssigned"], var.identity_type) || (var.managed_identity_id != null && trimspace(var.managed_identity_id) != "")
      error_message = "managed_identity_id is required when identity_type includes UserAssigned."
    }
  }
}
