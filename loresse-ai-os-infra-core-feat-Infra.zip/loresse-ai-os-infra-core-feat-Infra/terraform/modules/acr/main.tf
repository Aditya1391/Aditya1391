resource "azurerm_container_registry" "acr" {
  name                = var.acr_name
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = "Premium"
  admin_enabled       = false
  public_network_access_enabled = var.public_network_access_enabled
  network_rule_bypass_option    = var.network_rule_bypass_option
  tags                = var.tags

  dynamic "network_rule_set" {
    for_each = (
      var.network_default_action == "Deny" ||
      length(var.network_ip_rules) > 0
    ) ? [1] : []

    content {
      default_action = var.network_default_action

      dynamic "ip_rule" {
        for_each = var.network_ip_rules
        content {
          action   = "Allow"
          ip_range = ip_rule.value
        }
      }
    }
  }

  dynamic "identity" {
    for_each = length(var.identity_ids) > 0 ? [1] : []
    content {
      type         = "UserAssigned"
      identity_ids = var.identity_ids
    }
  }
}
