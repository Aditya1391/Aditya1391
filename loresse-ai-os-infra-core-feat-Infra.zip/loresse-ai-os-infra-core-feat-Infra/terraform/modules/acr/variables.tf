variable "acr_name" {
  description = "Name of the Azure Container Registry"
  type        = string
}

variable "resource_group_name" {
  description = "Resource group name"
  type        = string
}

variable "location" {
  description = "Azure region"
  type        = string
}

variable "tags" {
  description = "Tags to assign to ACR"
  type        = map(string)
  default     = {}
}

variable "identity_ids" {
  description = "Optional user-assigned identity IDs to attach to ACR"
  type        = list(string)
  default     = []
}

variable "public_network_access_enabled" {
  description = "Whether ACR public network access is enabled"
  type        = bool
  default     = true
}

variable "network_rule_bypass_option" {
  description = "Bypass option for ACR network rules (AzureServices or None)"
  type        = string
  default     = "None"
}

variable "network_default_action" {
  description = "Default action for ACR network rules (Allow or Deny)"
  type        = string
  default     = "Allow"
}

variable "network_ip_rules" {
  description = "Public IP CIDR ranges allowed to access ACR"
  type        = list(string)
  default     = []
}

variable "network_subnet_ids" {
  description = "Subnet IDs allowed to access ACR"
  type        = list(string)
  default     = []
}
